// precompiler directives
#ifndef SIMACCESS_H
#define SIMACCESS_H

// header file
#include <stdio.h>
#include "Simtimer.h"
#include "MetaDataAccess.h"
#include "StringUtils.h"
#include "ConfigAccess.h"
#include <pthread.h>

// global constants
typedef enum { 
               DEFAULT_STATE,
               NEW_STATE,
               READY_STATE,
               RUNNING_STATE,
               EXIT_STATE } ProcState;
     
typedef enum { 
               NOT_OP,
               FOUND_OP} OpManipCode;
               

typedef struct PCBType
   {
    int state;
    int procId;
    int runTime;
    OpCodeType *crtProcess; // points to the start node of the PCB (which is A(start))
    
    long memAvailable;  // the total memory authorized
    struct PCBType *next;
   } PCBType;

typedef struct StrBufferType
   {
    char strBuffer[ 100 ];
    struct StrBufferType *next;
   } StrBufferType;
   
//------------nre for MMU--------

typedef struct MMUType
   {
    long memAuth;
    long memAllocStart; // the memory allcated
    long memAllocEnd;
    long memAccStart;   // for an memory access request
    long memAccEnd;
    
    // next pointer
    struct MMUType *next;
    
   } MMUType;

//-----------------------------------


// function prototype

//******* sim03 ********
OpCodeType* findNextProcess( OpCodeType *mdPtr );

PCBType *createPCBList( PCBType *headPtr, int ctrOfProc, 
                   ConfigDataType *configDataPtr, OpCodeType *mdPtr );
PCBType* sortSJF_N( PCBType *PCBHeadPtr, OpCodeType *mdPtr );

   
MMUType *createMMUUnit( OpCodeType *mdPtr, PCBType *crtPCBPtr);

MMUType *createMMUList( MMUType *headPtr, MMUType *memUnit );

void storeMMUData( MMUType **mmuUnit, OpCodeType *crtMdPtr );

Boolean checkMemSpace( MMUType *memUnit, MMUType *mmuHeadPtr,
                                          OpCodeType *crtMdPtr);

void memValToStr( int opValue, MMUType *memUnit, char *destStr );

StrBufferType *saveBuffer_M(StrBufferType* strBfrPtr, char *timeStr, int procId,
       OpCodeType *crtMdPtr, int logToCode, MMUType *memUnit, char *flag );
               
StrBufferType *runOpCode_M( char *timeStr, int logToCode, 
                StrBufferType *strBfrPtr, PCBType *crtPCBPtr,
                  OpCodeType *crtMdPtr, MMUType **mmuUnit, MMUType *mmuHeadPtr );

StrBufferType *displaySegFault(StrBufferType* strBfrPtr,
                     char *timeStr, int procId, int logToCode );

MMUType *clearMMUList( MMUType *localPtr );

//******* sim03 ********


void runProg( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                     char *timeStr );
void opCodeAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                      PCBType *PCBHeadPtr, char *timeStr,
                        StrBufferType *strBfrPtr);

StrBufferType *runOpCode_P( int cycleTime, char *timeStr,
   int logToCode, StrBufferType *strBfrPtr, int procId, OpCodeType *crtMdPtr );

StrBufferType *saveBuffer(StrBufferType* strBfrPtr, char *timeStr,
               int procId, OpCodeType *crtMdPtr, char *flag , int logToCode );
               
void pthreadAccess( int cycleTime );

StrBufferType *runOpCode_IO( int ioCycleRate, char *timeStr, int logToCode,
                   StrBufferType *strBfrPtr, int procId, OpCodeType *crtMdPtr );
                  
int getTimeOfAProc( ConfigDataType *configDataPtr, OpCodeType *mdPtr );
int getCycleTime( int cycleRate, int opValue);
void *entryFunction( void *param );

int getNumOfProcess( OpCodeType *localPtr );


void setProcState( PCBType *localPtr, ProcState destState );
void setAllProcState( PCBType *localPtr, ProcState destState );


PCBType *clearPCBList( PCBType *localPtr );

int isNewProc( OpCodeType* localPtr );

StrBufferType *outputManager( StrBufferType *bfrHeadPtr, char *string, int logToCode );
void storeFile( char *fileName, StrBufferType *headBfrPtr );
StrBufferType *linkBufferList( StrBufferType *bfrHeadPtr,
                                          StrBufferType *newNode );
StrBufferType *storeHeader( StrBufferType *headBfrPtr, ConfigDataType *configPtr );
StrBufferType *clearStrBfrList( StrBufferType *localPtr );




// end directives
#endif

