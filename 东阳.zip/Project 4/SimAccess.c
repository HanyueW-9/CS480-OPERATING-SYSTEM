// header files
#include "SimAccess.h"


/*
Function name: runProg
Description: major function to run the program
*/
void runProg( ConfigDataType *configDataPtr, OpCodeType *mdPtr,  char *timeStr )
   {
    // initialize function/variables
    
        // initialize tempMdPtr
        OpCodeType *tempMdPtr = mdPtr ;
        
        // initialize counter for the number of processes
        int procCounter = 0;
        
        // initialize the head pointer of PCB
        PCBType *PCBHeadPtr = NULL;
        
        // initialize the sign of where to log
        int logToCode = configDataPtr->logToCode;
        
        // initialize the buffer of a string stored
        char buffer[ MAX_STR_LEN ];
        
        // initialize the link list of the buffer
        StrBufferType *strBfrPtr = NULL;
        
        // intialize the temp scheduler
        int scheduler =  configDataPtr->cpuSchedCode;
    
    // store Log File Header info to file
        // function: storeHeader
    strBfrPtr = storeHeader( strBfrPtr, configDataPtr );
    
    // display (or not) simulation component title
    // store buffer to a link list (output)
        // function: outputManager
    sprintf( buffer, "=================\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

    sprintf( buffer, "Begin Simulation\n\n" );
    
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
    // get the opLtr (check if it's S(start))
    if( tempMdPtr->opLtr == 'S'
        && compareString( tempMdPtr->opName, "start" ) == STR_EQ )
       {
        // start time 
        // function: accessTimer
        accessTimer( ZERO_TIMER, timeStr );
        
        // printf "OS: System Start"
        sprintf( buffer, "  %s, OS: System Start\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

        // create PCB link list according to Applications from metaData file
            // function: getNumOfProcess
        procCounter = getNumOfProcess( tempMdPtr );
        
            // function: createPCBList
        PCBHeadPtr = createPCBList( PCBHeadPtr, procCounter, configDataPtr, mdPtr );
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Create Process Control Blocks\n", timeStr);
   	  strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
   	  
        // initialize all processes in New state
            // function: setAllProcState
        setAllProcState( PCBHeadPtr, NEW_STATE);
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: All processes initialized in New state\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // set all processes in Ready state
        setAllProcState( PCBHeadPtr, READY_STATE);
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: All processes now set in Ready state\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       
        // go to next pointer
        tempMdPtr = tempMdPtr->next;
        
                   
        // manipulate processes in order according to cpu scheduling
        switch( scheduler )
           {
            // case CPU_SCHED_FCFS_N_CODE
            case CPU_SCHED_FCFS_N_CODE:
               
               // manipulate I/O/P operation commands in original order
               opCodeAccess( configDataPtr, tempMdPtr, PCBHeadPtr, timeStr, strBfrPtr );
               break;
            
            // case CPU_SCHED_SJF_N_CODE
            case CPU_SCHED_SJF_N_CODE:
            
               // sort processes in order by their total operation times
               // from shortest to longest
                  //function: sortSJF-N
               PCBHeadPtr = sortSJF_N( PCBHeadPtr, mdPtr );
                
               // manipulate I/O/P operation commands
               opCodeAccess( configDataPtr, tempMdPtr, PCBHeadPtr, timeStr, strBfrPtr );
               break;
               
// -----------------------------Sim04------------------------------------------
            case CPU_SCHED_FCFS_P_CODE:
               
               // manipulate I/O/P operation commands in preemptive mode
                  // function opCodePreemptAccess
               opCodePreemptAccess( configDataPtr, tempMdPtr, PCBHeadPtr,
                                     timeStr, strBfrPtr);
               break;
            
            case CPU_SCHED_SRTF_P_CODE:
               
               PCBHeadPtr = sortSJF_N( PCBHeadPtr, mdPtr );
                  // function opCodePreemptAccess
               opCodePreemptAccess( configDataPtr, tempMdPtr, PCBHeadPtr,
                                     timeStr, strBfrPtr);
               break;
            
            case CPU_SCHED_RR_P_CODE:
               opCodePreemptAccess( configDataPtr, tempMdPtr, PCBHeadPtr,
                                     timeStr, strBfrPtr);
               break;
            
// -----------------------------Sim04------------------------------------------
            default:
               opCodeAccess( configDataPtr, tempMdPtr, PCBHeadPtr, timeStr, strBfrPtr );
               break;

           }

        // clear the PCB list
        clearPCBList( PCBHeadPtr );
        
        // printf "System stop"
        accessTimer( STOP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: System stop\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // display the message that complete the simulation
        sprintf( buffer, "\nEnd Simulation - Complete\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        sprintf( buffer, "===========================\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // add endline for vertical spacing
        sprintf( buffer, "\n" );
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
       }
   
   // check if output data to file
   if( logToCode == LOGTO_FILE_CODE || logToCode == LOGTO_BOTH_CODE )
      {
       // initialize a variable for file name
       char *logToFileName = configDataPtr->logToFileName;
       
       storeFile( logToFileName, strBfrPtr );
       
       if( logToCode == LOGTO_FILE_CODE )
          {
           // display successfully to make it user friendly
           printf( "End Simulation - Complete\n" );
           
           printf( "===========================\n");
          }
      }
   
   // clear strBfrPtr data
   strBfrPtr = clearStrBfrList( strBfrPtr );
   
   }
 
/*
Function name: runOpCode_IO
Description: modular function, specifically check input and output
*/
StrBufferType *runOpCode_IO( ConfigDataType *configDataPtr, char *timeStr,
                       int logToCode, StrBufferType *strBfrPtr, 
                       PCBType *crtPCBPtr, OpCodeType *crtMdPtr )
   {
    // initialize variables
    
       int procId = crtPCBPtr->procId;
       
       int ioCycleRate = configDataPtr->ioCycleRate;
    
       // initialize the buffer of a string stored
       char buffer[ STD_STR_LEN ];
       
       // simulate processing time,
          // function: getCycleTime, runTimer, getCycleTime
       int cycleTime = getCycleTime( ioCycleRate, crtMdPtr->opValue);
    
    if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
       {
        sprintf( buffer, "\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       }
       
        strBfrPtr = saveBuffer( strBfrPtr, timeStr, procId,
                              crtMdPtr, "start", logToCode );
                              
    if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
       {
        sprintf( buffer, "\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       }
                              
    if( isPreemptive( configDataPtr ) == False )
       {
        // call pthread
        pthreadAccess( cycleTime );
  
       }
    // otherwise, it's a preemptive scheduler
    else
       {
        // create threadType node
        ThreadType *threadNode = (ThreadType *) malloc( sizeof( ThreadType ) ); 
        
        threadNode->ioCycleTime = cycleTime;
        threadNode->PCBNode = crtPCBPtr;
        threadNode->PCBNode->crtMdNode = crtMdPtr;
        threadNode->configDataPtr = configDataPtr;
        threadNode->timeStr = timeStr;
        
        threadNode->PCBNode->intrpFlag = False;
        
        pthreadPreemption( threadNode );
        
        
        // set current Process  in BLOCKED state"
        setProcState( crtPCBPtr, BLOCKED_STATE );
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Process %d set in BLOCKED state\n", 
                                  timeStr, procId);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
       }
    
                            
    return strBfrPtr;
   }




/*
Function name: opCodeAccess
Description: manipulate op code
*/
void opCodeAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
             PCBType *PCBHeadPtr, char *timeStr, StrBufferType *strBfrPtr)
   {
    // initialize variables
        
        // for current PCB pointer
        PCBType *crtPCBPtr = PCBHeadPtr;
        
        // for current metadata pointer
        OpCodeType *crtMdPtr = crtPCBPtr->crtMdNode; 

        // initialize the sign of where to log
        int logToCode = configDataPtr->logToCode;

        
        // temp for configDataPtr->procCycleRate
        int procCycleRate = configDataPtr->procCycleRate;
        
        // total cycleTime for current operation
        int cycleTime;
        
        // initialize the buffer of a string stored
        char buffer[ STD_STR_LEN ];
        
        // initialize MMU unit and the head of list
        MMUType *mmuHeadPtr = NULL;
        MMUType *mmuUnit = NULL;
        
       do
          {
           
           // display the current process and its remaining time"
           if( crtMdPtr->opLtr == 'A'
              && compareString( crtMdPtr->opName, "start" ) == STR_EQ )
              {
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
                // set current Process  in RUNNING state"
                setProcState( crtPCBPtr, RUNNING_STATE );
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n\n", 
                                  timeStr, crtPCBPtr->procId);
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
                // go to next pointer, start runnning
                crtMdPtr = crtMdPtr->next;
               }
            
            // check if opLtr = 'P'
           if( crtMdPtr->opLtr == 'P' )
              {
               
               cycleTime = getCycleTime( procCycleRate, crtMdPtr->opValue);

               strBfrPtr = runOpCode_P( cycleTime, timeStr, logToCode,
                                       strBfrPtr, crtPCBPtr->procId, crtMdPtr);
              }
             // check if opLtr = 'I'  
           else if( crtMdPtr->opLtr == 'I' || crtMdPtr->opLtr == 'O' )
              {
               strBfrPtr = runOpCode_IO( configDataPtr, timeStr, logToCode,
                                     strBfrPtr, crtPCBPtr, crtMdPtr );
              }
              // check if opLtr = 'M'
           else if ( crtMdPtr->opLtr == 'M' )
              {
               // initialize MMU unit
                   // function: createMMU
               if( compareString( crtMdPtr->opName, "allocate" ) == STR_EQ )
                  {
                   
                   mmuUnit = createMMUUnit( crtMdPtr, crtPCBPtr );
                   
                   crtPCBPtr->MMUList = createMMUList( mmuHeadPtr, mmuUnit ); 
                  
                   crtPCBPtr->mmuUnit = mmuUnit;
                  }
                  
               strBfrPtr = runOpCode_M( timeStr, logToCode, strBfrPtr,
                            crtPCBPtr, crtMdPtr );
              }



        // go to next opCommand
        crtMdPtr = crtMdPtr->next;

        // check if opCommand arrives at A(end)
        // then go to next PCB pointer
        if(  ( crtMdPtr->opLtr == 'A'
              && compareString( crtMdPtr->opName, "end" ) == STR_EQ )
           ||
             ( crtPCBPtr->state == EXIT_STATE   ) )
           {
           
            if( crtPCBPtr->state != EXIT_STATE )
               {
                setProcState( crtPCBPtr, EXIT_STATE);
               
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "\n  %s, OS: Process %d ended and set in EXIT state\n",
                                      timeStr, crtPCBPtr->procId);
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
               }
            
            // free the MMU unit
            mmuHeadPtr = clearMMUList( mmuHeadPtr );
            
            free( crtPCBPtr->mmuUnit );
            crtPCBPtr->mmuUnit = NULL;

            // go to next PCB node
            crtPCBPtr = crtPCBPtr->next;
                
            if( crtPCBPtr != NULL )
               {
                // go to next opCommand if there are other PCBs
                crtMdPtr = crtPCBPtr->crtMdNode;         
               }
           }
          
          } while( crtPCBPtr != NULL );
    
   }


/*
Function name: sortSJF_N
Description: manage PCB link list and store it's running time
             using bubble sort
*/
PCBType* sortSJF_N( PCBType *PCBHeadPtr, OpCodeType *mdPtr )
   {
    // initialize variables
        
        // get the number of processes
        int procSize = getNumOfProcess( mdPtr );
        
        // initialize two nodes: procX, procY
        PCBType *procX = PCBHeadPtr;
        PCBType *procY = PCBHeadPtr->next;
        
        // initialize two previous nodes of X and Y
        PCBType *prevX = NULL;
        //PCBType *prevY = PCBHeadPtr;
        
        // initialize a temporary node to store the next node of procY
        PCBType *tempNode = NULL;
        
        // initialize the index of processes
        int index;
        
        // set a flag which indicates whether swap or not
        Boolean swapped = True;
        
    // only when there are 2 or more processes, we do the sort
    if( procSize > 1 )
       {
        while( swapped == True )
           {
            // set them to original value
            prevX = NULL;
            procX = PCBHeadPtr;
            procY = PCBHeadPtr->next;
            
            swapped = False;
            
            for( index = 0; index < procSize - 1; index++ )
               {
                if( procX->runTime > procY->runTime )
                   {
                    // set the flag to True
                    swapped = True;
                    
                     // swap nodes
                    // case 1: when procX is the head of the linked list
                    if( prevX == NULL )
                       {
                        PCBHeadPtr = procY;
                        
                        // keep the next node of procY
                        tempNode = procY->next;
                        
                        procY->next = procX;
                        
                        procX->next = tempNode;
                       }
                    // case 2: when procX is not the head of the list
                    else
                       {
                        prevX->next = procY;
                        
                        // keep the next node of procY
                        tempNode = procY->next;
                        
                        procY->next = procX;
                        
                        procX->next = tempNode;
                       }
                    
                    // swap the pointer of procX and procY
                    procX = procY;
                    procY = procX->next;
                   }
                   
                // update the prevX and prevY
                prevX = procX;

                // move procX and procY to next node
                procX = procX->next;
                procY = procY->next;
                
               }
           }
       }
       
    return PCBHeadPtr;
   }
   
/*
Function name: findNextPorcess
Description: find the metadata node (A(start)) using loop
*/
OpCodeType* findNextProcess( OpCodeType *mdPtr )
   {
    // initialize variables
        // for current Metadata pointer
        OpCodeType *crtMdPtr = mdPtr; 
        
	 
	 while( isNewProc( crtMdPtr ) != FOUND_OP  )
	    {
	     crtMdPtr = crtMdPtr->next;
	     
	     if( crtMdPtr->opLtr == 'S'
                && compareString( crtMdPtr->opName, "end" ) == STR_EQ )
	        {
	         return NULL;
	        }
	        
	    }
	 
	 return crtMdPtr;
	
   }


//---------------------------functions for MMU---------------------------
/*
Function name: createMMUList
*/
MMUType *createMMUList( MMUType *headPtr, MMUType *memUnit )
   {
    // initialize variables
    
       // initialize the temp pointer and current pointer
       MMUType *tempPtr = memUnit;
       
       MMUType *localPtr = headPtr;
       
    // check if headPtr is uninitialized
    if( headPtr == NULL )
       {
        headPtr = tempPtr;
        localPtr = tempPtr;
       }
    else
       {
        // go to the end of the list
        while( localPtr->next != NULL )
          {
           localPtr = localPtr->next;
          }
        
        // set memUnit to he last node of linked list
        localPtr->next = tempPtr;
       }

    // return head
    return headPtr;
   }

/*
Function name: createMMU
Description: create a MMu unit and store the total memory authorized for a given process 
*/
MMUType *createMMUUnit( OpCodeType *mdPtr, PCBType *crtPCBPtr)
   {
    // initialize variables;
    
    MMUType *memUnit = (MMUType *) malloc( sizeof( MMUType ) );
    
    memUnit->memAuth = crtPCBPtr->memAvailable;
    
    memUnit->memAllocStart = 0;
    
    memUnit->memAllocEnd = 0;
    
    memUnit->memAccStart = 0;
    
    memUnit->memAccStart = 0;
    
    memUnit->next = NULL;
	
    storeMMUData( &memUnit, mdPtr );
    
    // return value
    return memUnit;
   }
   
/*
Function name: clearMMUData
ALgorithm: frees allocated memory for MMU data
Precondition: pointer to MMU data linked list passed
              in as a parameter
Postcondition: MMU data memory is freed,
               pointer is set to null
Exceptions: none
Notes: none
*/
MMUType *clearMMUList( MMUType *localPtr )
   {
    // check that MMU data pointer is not null
    if( localPtr != NULL )
       {
        
        // check for local pointer's next node not null
        if( localPtr->next != NULL )
           {
            // call recursive function with next pointer
                // function: clearMMUList
            clearMMUList( localPtr->next );
           }
           
        // after recursive call, release memory to OS
            // function: free
        free( localPtr );
       }
    
    
    // set MMU data pointer to null (returned as parameter)
    return NULL;
   }
   
/*
Function name: runOpCode_M
*/
StrBufferType *runOpCode_M( char *timeStr, int logToCode, 
                StrBufferType *strBfrPtr, PCBType *crtPCBPtr,
                  OpCodeType *crtMdPtr )
   {
    // initialize variables
       int procId = crtPCBPtr->procId;
    
       // used to organize string
       char flagStr[ STD_STR_LEN ];
       
       MMUType *mmuUnit = crtPCBPtr->mmuUnit;
       
       // used to indicate the result of comparison of memory
       Boolean compareResult; 
    
    // save MMU unit data
       // function: storeMMUData 
    storeMMUData( &mmuUnit, crtMdPtr );
    
    // display Memory data
    strBfrPtr = saveBuffer_M( strBfrPtr, timeStr, procId,
                             crtMdPtr, logToCode, mmuUnit, NULL );
    
    // comparison
       // function: checkMemSpace
    compareResult = checkMemSpace( mmuUnit, crtPCBPtr->MMUList, crtMdPtr );
        
    // check the amount of memory requested is not larger than
    // that specified in the configuration file
       // if it does overlap (failure)
    if( compareResult == False )
       {
        // organize string
           // function : copyString, concatenateString
           copyString( flagStr, " failed to " );
           
           concatenateString( flagStr, crtMdPtr->opName );
           
        strBfrPtr = saveBuffer_M( strBfrPtr, timeStr, procId,
                       crtMdPtr, logToCode , mmuUnit, flagStr );
                   
        // free the MMU unit
        crtPCBPtr->MMUList = deleteMMUNode( crtPCBPtr->MMUList,  mmuUnit );

        
        crtPCBPtr->mmuUnit = NULL; // avoid dangling pointer
        
        strBfrPtr = displaySegFault( strBfrPtr, timeStr, procId, logToCode );
        
        // set this process's state to exit
        setProcState( crtPCBPtr, EXIT_STATE );
                
        char buffer[STD_STR_LEN];
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "\n  %s, OS: Process %d ended and set in EXIT state\n",
                                      timeStr, crtPCBPtr->procId);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
       }
       // if it does noet overlap(success)
    else
       {
        // organize string
           // function : copyString, concatenateString
           copyString( flagStr, " successful " );
           
           concatenateString( flagStr, crtMdPtr->opName );
        
        strBfrPtr = saveBuffer_M( strBfrPtr, timeStr, procId,
                       crtMdPtr, logToCode , mmuUnit, flagStr );
       }
    
    // return strBfrPtr
    return strBfrPtr;
   }

/*
Function name: deleteMMUNode
Description: delete the unvalid node from the MMU linked list
*/
MMUType *deleteMMUNode( MMUType *MMUHead, MMUType *removedNode )
   {
    // initialize variables
       MMUType *headPtr = MMUHead;
       
       // temp Node for current node
       MMUType *crtPtr = headPtr;
       
       // temp Node for previous node
       MMUType *prevPtr = headPtr;
       
    // check if the linked list is not empty
    if( MMUHead != NULL )
       {
        // find the node to be removed
        while( crtPtr != removedNode && crtPtr != NULL )
           {
            
            prevPtr = crtPtr;
            
            crtPtr = crtPtr->next;
           }
        
        // if the removed node is found
        if( crtPtr == removedNode )
           {
            
            // check if the node is the headPtr
            if( crtPtr == headPtr )
               {
                MMUHead = crtPtr->next;
               }
            else
               {
                prevPtr->next = crtPtr->next;
               }
            
            // free the node
            free(crtPtr);
           }
        // otherwise, doesn't find the removedNode, do nothing
        
       }
       
    // otherwise, do nothing
    return MMUHead;
   }


/*
Function name: checkMemSpace
Description: when memory needed > the max memory, return False;
             otherwise, return True;
*/
Boolean checkMemSpace( MMUType *mmuUnit, MMUType *mmuHeadPtr,
                                          OpCodeType *crtMdPtr)
   {
    // initialize variable
    Boolean result = True;
    
    // compare memUnit to previous MMU unit to make sure they don't have overlaps
    MMUType *prevMmuUnit = mmuHeadPtr;
    
    if( compareString( crtMdPtr->opName, "allocate" ) == STR_EQ )
       {
       
        // compare memory allocated to the total memory authorized
        if( ( mmuUnit->memAllocEnd - mmuUnit->memAllocStart ) > mmuUnit->memAuth )
           {
            result = False;
            return result;
           }

        // compare with other established memory segment
        while( prevMmuUnit != mmuUnit )
           {
                 
            if( ( mmuUnit->memAllocStart < prevMmuUnit->memAllocStart
                 && mmuUnit->memAllocEnd <= prevMmuUnit->memAllocStart )
                  ||
                     ( mmuUnit->memAllocStart >= prevMmuUnit->memAllocEnd
                       && mmuUnit->memAllocEnd > prevMmuUnit->memAllocEnd ) )
               {
                result = True;
               }
            else
               {
                // if it's False, return False directly to avoid iterate the mmu linked list
                result = False;
                
                return result;
               }
            
            prevMmuUnit = prevMmuUnit->next;
            

           }
        
        // otherwise, it's True
        
       }
       
    else if( compareString( crtMdPtr->opName, "access" ) == STR_EQ )
       {
        // compare memory requested to the memory allocated
        // compare with the established memory segments(including itself)
        while( prevMmuUnit != NULL )
           {
                 
            if( (mmuUnit->memAccEnd <= prevMmuUnit->memAllocEnd 
                && mmuUnit->memAccStart >= prevMmuUnit->memAllocStart ) )
               {
                result = True;
                return result;
               }
            else
               {
                // otherwise, set the flag to False instead of return False directly,
                // since the memory access request could access other memory 
                // allocated to that process
                result = False;
               }
            
            prevMmuUnit = prevMmuUnit->next;
            

           }
       }
    
    // return value
    return result;
   }

/*
Function name: storeMMUData
Precondition: when the opCode is M(allocate) or M(access)
*/
void storeMMUData( MMUType **mmuUnit, OpCodeType *crtMdPtr )
   {
    // initialize variables
    long opValue = (int) crtMdPtr->opValue;
    
    long base = (long)( opValue / 10000 );
    
    long offset = (long)( opValue % 10000 );
    
    if( compareString( crtMdPtr->opName, "allocate" ) == STR_EQ  )
       {
        //calculate the memory allocated
        (*mmuUnit)->memAllocStart = base;
        
        (*mmuUnit)->memAllocEnd = base + offset;
        
       }
    else if ( compareString( crtMdPtr->opName, "access" ) == STR_EQ )
       {
        //calculate the memory allocated
        (*mmuUnit)->memAccStart = base;
        
        (*mmuUnit)->memAccEnd = base + offset;

       }
       
   }
   

/*
Function name: memToStr
Description: change the opValue of memory to string;
             save the sum of base and offset to memUnit
*/
void memValToStr( int opValue, MMUType *memUnit, char *destStr )
   {
    // initialize variables
    long base = (long)( opValue / 10000 );
    
    long offset = (long)( opValue % 10000 );
    
    char sourceStr[ STD_STR_LEN ];
    
    // convert integer to string;
    sprintf( sourceStr, "%ld/%ld", base, offset );
    
    // return value
    copyString ( destStr, sourceStr);
   }

/*
Funtion name: displaySegFault
*/
StrBufferType *displaySegFault( StrBufferType* strBfrPtr,
                     char *timeStr, int procId, int logToCode )
   {
    // initialize variables
    char buffer[ STD_STR_LEN ];
    
    char opString[ MAX_STR_LEN ];
    
    copyString( opString, "experiences segmentation fault" );
    
    // keep time
    accessTimer( LAP_TIMER, timeStr );
    
    sprintf( buffer, "\n  %s, OS: Process %d %s",
                                   timeStr, procId, opString);
                                   
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    return strBfrPtr;
   }

/*
Function name: saveBuffer_M
Description: save them to buffer or not according to logToCode
*/
StrBufferType *saveBuffer_M(StrBufferType* strBfrPtr, char *timeStr, int procId,
       OpCodeType *crtMdPtr, int logToCode, MMUType *memUnit, char *flag )
   {
    // initialize variables
    char buffer[ STD_STR_LEN ];
    
    char opString[ MAX_STR_LEN ];
    
    char opValueStr[ MAX_STR_LEN ];
    
    copyString( opString, "MMU" );
    
    // construct a string according to opLtr
    if( flag == NULL )
       {
        if( compareString( crtMdPtr->opName, "allocate" ) == STR_EQ  )
           {
            concatenateString( opString, " attempt to allocate ");
           }
        else if( compareString( crtMdPtr->opName, "access" ) == STR_EQ )
           {
           concatenateString( opString, " attempt to access ");
           }
       
        memValToStr( crtMdPtr->opValue, memUnit, opValueStr ); 
            
        concatenateString( opString, opValueStr );
       }
    else
       {
        concatenateString( opString, flag );
       }
    
    // keep time
    accessTimer( LAP_TIMER, timeStr );
    
    sprintf( buffer, "  %s, Process %d, %s\n",
                                   timeStr, procId, opString);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    return strBfrPtr;
   }

//-----------------------------------------------------------------

/*
Function name:runOpCode_P
Description: modular function, specifically check opLtr 'P'
*/
StrBufferType *runOpCode_P( int cycleTime, char *timeStr, int logToCode,
          StrBufferType *strBfrPtr, int procId, OpCodeType *crtMdPtr)
   {
    // initialize variables 

    strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "start" , logToCode );
    
    // simulate processing time
    // function: runTimer
    runTimer( cycleTime );
    
    // printf "run operation end"
    strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "end" , logToCode );
    
    // return strBfrPtr
    return strBfrPtr;
   }


/*
Function name: saveBuffer
Description: save them to buffer or not according to logToCode
*/
StrBufferType *saveBuffer(StrBufferType* strBfrPtr, char *timeStr,
               int procId, OpCodeType *crtMdPtr, char *flag , int logToCode )
   {
    // initialize variables
    char buffer[ STD_STR_LEN ];
    
    char opString[ MAX_STR_LEN ];
    
    copyString( opString, crtMdPtr->opName );
    
    // set a string according to opLtr
    switch (crtMdPtr->opLtr)
       {
        case 'I': 
           concatenateString( opString, " input ");
           break;
        case 'O':
           concatenateString( opString, " output ");
           break;
        case 'P':
           concatenateString( opString, " operation ");
           break;
       }


    concatenateString( opString, flag);
    
    // keep time
    accessTimer( LAP_TIMER, timeStr );
    
    sprintf( buffer, "  %s, Process %d, %s\n",
                                   timeStr, procId, opString);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    

    return strBfrPtr;
   }

/*
Function name: pthreadAccess
*/
void pthreadAccess( int cycleTime )
   {
    // define thread reference variables
    pthread_t thread;

    // create pthreads
    pthread_create( &thread, NULL, entryFunction, &cycleTime );
         
    // join everything back up
    pthread_join( thread, NULL);
   }



/*
Function name:clearStrBfrList
*/
StrBufferType *clearStrBfrList( StrBufferType *localPtr )
   {
    // check for local pointer not set to null (list not empty)
    if( localPtr != NULL )
       {
        // check for local pointer's next node not null
        if( localPtr->next != NULL )
           {
            // call recursive function with next pointer
                // function: clearStrBfrList
            clearStrBfrList( localPtr->next );
           }
           
        // after recursive call, release memory to OS
            // function: free
        free( localPtr );
       }
       
    // return null to calling function
    return NULL;
   }
/*
Function name: storeHeader
Description: store config data into the object file 
*/
StrBufferType *storeHeader( StrBufferType *strBfrPtr, ConfigDataType *configPtr )
   {
    // initialize variables
    
        // initialize the buffer of a string stored
        char buffer[ MAX_STR_LEN ];
        
        char displayString[ STD_STR_LEN ];
    
        int logToCode = LOGTO_FILE_CODE;
        
    sprintf( buffer, "==================================================\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    
    sprintf( buffer, "Simulator Log File Header\n\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

    sprintf( buffer, "File Name                       : %s\n", 
                                  configPtr->metaDataFileName);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    configCodeToString( configPtr->cpuSchedCode, displayString );

    sprintf( buffer, "CPU Scheduling                  : %s\n", 
                                                displayString);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Quantum Cycles                  : %d\n", 
                                  configPtr->quantumCycles);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Memory Available (KB)           : %ld\n", 
                                  configPtr->memAvailable);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Processor Cycle Rate (ms/cycle) : %d\n", 
                                  configPtr->procCycleRate);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "I/O Cycle Rate (ms/cycle)       : %d\n\n", 
                                  configPtr->ioCycleRate);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    // return head pointer
    return strBfrPtr;
   }


/*
Function name: storeFile
Description: store the string buffer link list to the object file
*/
void storeFile( char *fileName, StrBufferType *headBfrPtr )
   {
    // initialize a loacl pointer pointint to the head pointer
    StrBufferType *localPtr = headBfrPtr;
    
    
    // create file named fileName in write mode
    FILE *fptr = fopen( fileName, "w" );
    
    
    // traverse the link list
    while( localPtr != NULL )
       {
        fprintf( fptr, "%s", localPtr->strBuffer );
        
        // go to next pointer
        localPtr = localPtr->next;
       
       }

    // close file
    fclose( fptr );
    
   }


/*
Function Name: outputManager
Description: decide if output info to monitor according to logToCode
*/
StrBufferType *outputManager( StrBufferType *bfrHeadPtr, char *string, int logToCode )
   {
    // initialize temporary pointer of StrBufferType
    StrBufferType *newPtr = NULL;
    
    // access memory for new link/node
    newPtr = (StrBufferType *) malloc(sizeof( StrBufferType ));
    
    // assign all values to newly created node
    copyString( newPtr->strBuffer, string );
    
    // assign next pointer to NULL
    newPtr->next = NULL;
    
    // create the link list
    bfrHeadPtr = linkBufferList( bfrHeadPtr, newPtr );

    // check if output the string
    if( logToCode == LOGTO_MONITOR_CODE || logToCode == LOGTO_BOTH_CODE )
       {
        printf( "%s", string );
       }
    
    // return head pointer
    return bfrHeadPtr;
   }

/*
Function name: linkBufferList
*/
StrBufferType *linkBufferList( StrBufferType *headPtr,
                                          StrBufferType *newNode )
   {
    // initialize  a current pointer
    StrBufferType *localPtr = NULL;
    
    // initialize  a current pointer
    StrBufferType *tempPtr = newNode;
    
    // check if headPtr is undefined
    if( headPtr == NULL )
       {
        // set headPtr to newNode;
        headPtr = tempPtr;
        
        // return head pointer
        return headPtr;
       }
    
    localPtr = headPtr;
    
    // otherwise
    while( localPtr->next != NULL )
       {
        // go to next pointer until at the end of the list
        localPtr = localPtr->next;
       }

    // set local's next pointer to newNode
    localPtr->next = tempPtr;

    // return head pointer 
    return headPtr;
   }
   

/*
Function name: isNewProc
Description: check if there is a new process coming in
*/
int isNewProc( OpCodeType* localPtr )
   {
    // initialize temp pointer
    OpCodeType *tempPtr = localPtr;
    
    
    if( tempPtr->opLtr == 'A'
        && compareString( tempPtr->opName, "start" ) == STR_EQ )
       {
     
         // if A(start) has found before, then set result to FOUND_OP
         
         return FOUND_OP;
       }
       
    // otherwise, it's not a start of a new process;
    return NOT_OP;
   }


/*
Function name: setProcState
*/
void setProcState( PCBType *localPtr, ProcState destState )
   {    
    // set local pointer's state to destination
    localPtr->state = destState;
   }

/*
Function name: setAllProcState
*/
void setAllProcState( PCBType *localPtr, ProcState destState )
   {
    // initialize temporary pointer
    PCBType *tempPtr = localPtr;
    
    while( tempPtr != NULL )
       {
        // set local pointer's state to destination
        tempPtr->state = destState;
        
        // change the state of current Pointer
        setProcState( tempPtr, destState );
        
        // go to next pointer;
        tempPtr = tempPtr->next;
       }
   }

/*
Function Name: createPCBList
*/
PCBType *createPCBList( PCBType *headPtr, int ctrOfProc, 
                   ConfigDataType *configDataPtr, OpCodeType *mdPtr )
   {
    // initialize function/variables
    
        // initialize index of the loop
        int index;
        
        // initialize the temp metddata pointer
        OpCodeType *crtMdPtr = mdPtr; 
        
        // initialize the temp pointer and current pointer
        PCBType *tempPtr = NULL;
        PCBType *localPtr = NULL;
        
    // create specific number of PCBs with respect to the counter of it
        // using loop
    for( index = 0; index < ctrOfProc; index++ )
       {
        // access memory for new link/node
            // function: malloc
        tempPtr = ( PCBType *) malloc( sizeof( PCBType ) );
         
        // assign all values to newly created node
        tempPtr->state = DEFAULT_STATE;
        tempPtr->procId = index;
        tempPtr->memAvailable = configDataPtr->memAvailable;
        
        // link new process and running time
           // find the head (A(start)) of next process
               // function: findNextProcess
        crtMdPtr = findNextProcess( crtMdPtr );
           
        tempPtr->runTime = getTimeOfAProc( configDataPtr, crtMdPtr );
        
        tempPtr->intrpFlag = False;

        tempPtr->crtMdNode = crtMdPtr;
        
        tempPtr->MMUList = NULL;
        
        tempPtr->mmuUnit = NULL;
        
        // set all PCB's headMdPtr to the head opCode
        if( index == 0 )
           {
            tempPtr->headMdPtr = crtMdPtr;       
           }
        else
           {
            tempPtr->headMdPtr = headPtr->headMdPtr;
           }
        
        // assign next pointer to null
        tempPtr->next = NULL;
        
        crtMdPtr = crtMdPtr->next; // in order to find next Process
        
        
        // check if headPtr is uninitialized
        if( headPtr == NULL )
           {
            // set headPtr to tempPtr
            headPtr = tempPtr;
            localPtr = tempPtr;
           }
        // otherwise
        else
           {
            // set local's next pointer to temp
            localPtr->next = tempPtr;
            
            // move local to next  // noticed!!
            localPtr = localPtr->next;

           }
       }
       
    // return current local pointer
    return headPtr;
   }

/*
Function Name: getNumOfProcess
*/
int getNumOfProcess( OpCodeType *localPtr )
   {
    // create variable for counter
    int counter = 0;
    
    // temp for process pointer
    OpCodeType *tempPtr = localPtr;
    
    // iterate through the link list
    while( tempPtr != NULL )
       {
        // if opLtr is 'A' and opName is "start"
        if( tempPtr->opLtr == 'A' 
            && compareString( tempPtr->opName, "start" ) == STR_EQ )
           {
            // increment the counter
            counter++;
           }
        
        // go to next pointer
        tempPtr = tempPtr->next;
       }
       
    // return the number of processes
    return counter;
    
   }

   
/*
Function name: entryFunction
               rewrite runTimer()
*/
void *entryFunction( void *param )
   {
    
    int cycleTime = *( (int *) param);
    
    // Call tunTimer to fake the process time
    runTimer(cycleTime);
    
    // stud return value
    return NULL;
   }

/*
Function name: getTimeOfAProc
*/
int getTimeOfAProc( ConfigDataType *configDataPtr, OpCodeType *mdPtr )
   {
    
    // initialize variables
        // for temp data
        OpCodeType *crtMdPtr = mdPtr;
        
        // temp for configDataPtr->ioCycleRate
        int ioCycleRate = configDataPtr->ioCycleRate;
        
        // temp for configDataPtr->procCycleRate
        int procCycleRate = configDataPtr->procCycleRate;
    
        // for sum of time remaining
        int sumTime = 0;
    
    // loop the link list
    while( crtMdPtr != NULL )
       {
        
        // check if opLtr is P, I, or O
        switch( crtMdPtr->opLtr )
           {
            case 'P':
               sumTime += crtMdPtr->opValue * procCycleRate;
               break;
               
            case 'I':
            case 'O':
               sumTime += crtMdPtr->opValue * ioCycleRate;
               break;
           }
        
        // go to next link
        crtMdPtr = crtMdPtr->next;
        
        // check if crtMdPtr->opLtr is 'A' and opName is "end"
        // which means one process gets done
        // then return sumTime
        if( ( crtMdPtr->opLtr == 'A'
              && compareString( crtMdPtr->opName, "end" ) == STR_EQ ) )
           {
            return sumTime;
           }
       }
    
    // complete traverse
    return sumTime;
   }

/*
Function name: getCycleTime
Precondition: pass cycleRate and opValue of a certain operation
Postcondition: return the total time consisting of the multiplication
               of cycleRate * opValue 
*/
int getCycleTime( int cycleRate, int opValue)
   {
    return (cycleRate * opValue);
   }

/*
Function name: clearPCBList
*/
PCBType *clearPCBList( PCBType *localPtr )
   {
    // check for local pointer not set to null (list not empty)
    if( localPtr != NULL )
       {
        // check for local pointer's next node not null
        if( localPtr->next != NULL )
           {
            // call recursive function with next pointer
                // function: clearPCBList
            clearPCBList( localPtr->next );
           }
        
        // after recursive call, release memory to OS
        free( localPtr );
       }

    // return null to calling function
    return NULL;
   }


   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
