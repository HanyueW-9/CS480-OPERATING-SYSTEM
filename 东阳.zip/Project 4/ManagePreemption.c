// header files
#include "SimAccess.h"
#include "ManagePreemption.h"


/*
Function name: opCodePreemptAccess
Description: manipulate opCode in preemptive scheduler
*/ 
void opCodePreemptAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                    PCBType *PCBHeadPtr, char *timeStr,
                    StrBufferType *strBfrPtr )
   {
    // initialize variables
        // for current PCB pointer
        PCBType *crtPCBPtr = PCBHeadPtr;
        
        // for current metadata pointer
        OpCodeType *crtMdPtr = crtPCBPtr->crtMdNode; 

        // initialize the sign of where to log
        int logToCode = configDataPtr->logToCode;
        
        // initialize the buffer of a string stored
        char buffer[ STD_STR_LEN ];
        
        // initialize MMU unit and the head of list
        MMUType *mmuUnit = NULL;

    // check if all processes do not exit
      // function: checkAllProcState, numOfProcInReady
    while( checkAllProcState( PCBHeadPtr, EXIT_STATE) == False )
       {
        
        // display the current process and its remaining time"
        if( crtMdPtr->opLtr == 'A'
           && compareString( crtMdPtr->opName, "start" ) == STR_EQ )
           {
           
             accessTimer( LAP_TIMER, timeStr );
             sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
             strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
             // set current Process  in RUNNING state"
             setProcState( crtPCBPtr, RUNNING_STATE );
             accessTimer( LAP_TIMER, timeStr );
             sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n", 
                                  timeStr, crtPCBPtr->procId);
             strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
             
                
             // go to next pointer, start runnning
                crtMdPtr = crtMdPtr->next;
                crtPCBPtr->crtMdNode = crtMdPtr;
            }
               
        // check if opLtr = 'P'
        if( crtMdPtr->opLtr == 'P' )
           {
           strBfrPtr = runOpCode_P_preempt( configDataPtr, timeStr,
                                   strBfrPtr, &crtPCBPtr, PCBHeadPtr, crtMdPtr);
           
           if( crtMdPtr->opValue == 0 )
              {
               // go to next opCommand
               crtMdPtr = crtMdPtr->next;
              }
           }
           
        // check if opLtr = 'I'
        else if( crtMdPtr->opLtr == 'I' || crtMdPtr->opLtr == 'O' )
           {
            strBfrPtr = runOpCode_IO( configDataPtr, timeStr, logToCode,
                                     strBfrPtr, crtPCBPtr, crtMdPtr );

            // when all processes are not in block nor exit, do following operations
            if( checkProcInStates( PCBHeadPtr, BLOCKED_STATE, EXIT_STATE ) == False )
               {
                crtPCBPtr = PCBHeadPtr;
                
                while( crtPCBPtr->state != READY_STATE )
                   {
                    // go to next process
                    crtPCBPtr = crtPCBPtr->next;
                   }
                   
                crtMdPtr = crtPCBPtr->crtMdNode;
                
               }
           }
           
        // check if opLtr = 'M'
        else if ( crtMdPtr->opLtr == 'M' )
           {
            
            // initialize MMU unit
               // function: createMMU
            if( compareString( crtMdPtr->opName, "allocate" ) == STR_EQ )
               {
                mmuUnit = createMMUUnit( crtMdPtr, crtPCBPtr );
                   
                crtPCBPtr->MMUList = createMMUList( crtPCBPtr->MMUList, mmuUnit );
               
                crtPCBPtr->mmuUnit = mmuUnit;
                
               }
            
            // newline
            sprintf( buffer, "\n");
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            strBfrPtr = runOpCode_M( timeStr, logToCode, strBfrPtr,
                            crtPCBPtr, crtMdPtr );

            if( crtPCBPtr->state == EXIT_STATE )
               {
                clearPCB_MMU( crtPCBPtr );
                
                // go to next PCB node
                if( checkProcInStates( PCBHeadPtr, BLOCKED_STATE, EXIT_STATE ) == False )
                  {
                    crtPCBPtr = crtPCBPtr->next;
                    crtMdPtr = crtPCBPtr->crtMdNode;
                  }
               }
            else
               {
                // go to next opCommand
                crtMdPtr = crtMdPtr->next;
               }
           }
        
        // update it
        crtPCBPtr->crtMdNode = crtMdPtr;
        
        // when there is one or more process in ready state 
        //  or there is no process in running state
        // then sort them again
        if( numOfProcInReady( PCBHeadPtr ) >= 1 
             &&  isInState( PCBHeadPtr, RUNNING_STATE ) == False )
           {
            if( configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE )
               {
                // sort processes in order by their total operation times
                // from shortest to longest
                  //function: sortSJF-N
                PCBHeadPtr = sortSJF_N( PCBHeadPtr, mdPtr );
           
                // find the shortest process which is in READY state
                   // function: findReadyProc
                crtPCBPtr = findReadyProc( PCBHeadPtr );
                crtMdPtr = crtPCBPtr->crtMdNode;
               }
            
            // avoid repeated prompt
            if( crtMdPtr->opLtr != 'A'
                   || compareString( crtMdPtr->opName, "start" ) != STR_EQ )
               {
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
                 // set current Process  in RUNNING state"
                 setProcState( crtPCBPtr, RUNNING_STATE );
                 accessTimer( LAP_TIMER, timeStr );
                 sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n", 
                                  timeStr, crtPCBPtr->procId);
                 strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                }
                
           }

        // check if opCommand arrives at A(end)
        // then go to next PCB pointer
        if( ( crtMdPtr->opLtr == 'A' && 
                     compareString( crtMdPtr->opName, "end" ) == STR_EQ )
           && ( crtPCBPtr->state != EXIT_STATE   )  )
           {
            setProcState( crtPCBPtr, EXIT_STATE);
            
            
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: Process %d ended and set in EXIT state\n",
                                      timeStr, crtPCBPtr->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            // free the memory of MMU
            clearPCB_MMU( crtPCBPtr );
            
            // go to next PCB node
            crtPCBPtr = crtPCBPtr->next;
            
            if( crtPCBPtr != NULL )
               {
                // go to next opCommand if there are other PCBs
                crtMdPtr = crtPCBPtr->crtMdNode;         
               }
           }

        // check if processes are in BLOCKED state or in EXIT processes
        // which means they are not in READY state
        if( checkProcInStates( PCBHeadPtr, BLOCKED_STATE, EXIT_STATE ) == True
           &&
            checkAllProcState( PCBHeadPtr,  EXIT_STATE ) != True )
           {
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: System/CPU idle\n", timeStr );
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            while( isInterrupt( PCBHeadPtr ) != True )
               {
                // wait untill one opCode complete
               }
            
            // find current process which interrupt
                // function: findIntrpProc()
            PCBType *intrpProcess = findIntrpProc( PCBHeadPtr );
            
            crtPCBPtr = intrpProcess;
            
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: Interrupt called by process %d\n\n",
                                      timeStr, crtPCBPtr->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            // display the end
            strBfrPtr = saveBuffer( strBfrPtr,
            timeStr, crtPCBPtr->procId, intrpProcess->crtMdNode, "end", logToCode );
            
            // set current Process  in READY state"
            setProcState( crtPCBPtr, READY_STATE );
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "\n  %s, OS: Process %d set in READY state\n", 
                                 timeStr, crtPCBPtr->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            // set the interrupt Process's mdPtr to next opCode
            intrpProcess->crtMdNode = intrpProcess->crtMdNode->next;
            
            // set intrpFlag to False
            crtPCBPtr->intrpFlag = False;
            
            
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
             // set current Process  in RUNNING state"
             setProcState( crtPCBPtr, RUNNING_STATE );
             accessTimer( LAP_TIMER, timeStr );
             sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n", 
                                  timeStr, crtPCBPtr->procId);
             strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            // go to next opCode of current process which interrupt
            crtMdPtr = crtPCBPtr->crtMdNode;

           }
       }
   }
//***************************************************************PopCodeAccess

/*
Function name: clearPCB_MMU
Description: free the memory of mmu in PCB
*/
void clearPCB_MMU( PCBType *crtPCBPtr )
   {
    if( crtPCBPtr->MMUList != NULL )
       {
        crtPCBPtr->MMUList = clearMMUList( crtPCBPtr->MMUList );
        crtPCBPtr->mmuUnit = NULL; // avoid dangling pointer
       }

   }


/*
Function name: checkAllProcState
*/
Boolean checkAllProcState( PCBType *PCBHeadPtr, int destState )
   {
    // initialize temporary pointer
    PCBType *tempPtr = PCBHeadPtr;
    
    while( tempPtr != NULL )
       {
        // if one of the process's state is not the destState,
        // return False
        if( tempPtr->state != destState )
           {
            return False;
           }
        
        // go to next pointer;
        tempPtr = tempPtr->next;
       }
       
    // otherwise, return True
    return True;
   }

/*
Function name: runOpCode_P_preempt
Description: modular function, specifically check opLtr 'P'
*/
StrBufferType *runOpCode_P_preempt( ConfigDataType *configDataPtr, char *timeStr,
                              StrBufferType *strBfrPtr,
                             PCBType **currentPCBNode, PCBType *PCBHeadPtr,
                             OpCodeType *crtMdPtr)
   {
    // initialize variables 
       
       int singleCycleTime = configDataPtr->procCycleRate;
       
       PCBType *crtPCBPtr = *currentPCBNode;
       
       int procId = crtPCBPtr->procId;

       int cycleCounter = 0;
       
       PCBType *interruptedProc = NULL;
       
       // initialize the sign of where to log
       int logToCode = configDataPtr->logToCode;
    
       // initialize the buffer of a string stored
       char buffer[ STD_STR_LEN ];
       
    if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
         || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
       {
        sprintf( buffer, "\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       } 
               
    strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "start" , logToCode );

    while( crtMdPtr->opValue != 0 )
       {
        
        // when scheduler is RR-P
        if( configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
           {
            if( cycleCounter == configDataPtr->quantumCycles )
               {
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "\n  %s, OS: Process %d experiences quantum time out\n",
                                  timeStr, procId );
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
               
                // set current process to READY state
                // function name: setProcState()
                setProcState( crtPCBPtr, READY_STATE );
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d set in READY state\n", 
                                      timeStr, procId);
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
               
                break;
               }
        
            // increment counter
            cycleCounter++;
           }
        
        // simulate processing time
            // function: runTimer
        runTimer( singleCycleTime );
        crtPCBPtr->runTime -= singleCycleTime;
        crtMdPtr->opValue--;
        
        
        // a loop in which check if it's interrupted by other process
        // function findIntrpProc()
        if( isInterrupt( PCBHeadPtr ) == True )
           {
            
            interruptedProc = findIntrpProc( PCBHeadPtr );
            
            //****
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "\n  %s, OS: Process %d interrupt by process %d\n",
                                  timeStr, procId, interruptedProc->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            //***
            // set current process to READY state
                // function name: setProcState()
            setProcState( crtPCBPtr, READY_STATE );

            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: Process %d set in READY state", 
                                  timeStr, procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
                 || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
                 || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
               {
                sprintf( buffer, "\n");
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
               }
            
            // printf "I/O operation end"
            strBfrPtr = saveBuffer(strBfrPtr, timeStr, interruptedProc->procId,
                        interruptedProc->crtMdNode, "end" , logToCode );
            
            if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
                 || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
                 || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
               {
                sprintf( buffer, "\n");
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
               } 
            
            
            // set interruptedProc's mdPtr to next opCode
            interruptedProc->crtMdNode = interruptedProc->crtMdNode->next;
            
            // set the interrupt process to READY state
            setProcState( interruptedProc, READY_STATE );
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "  %s, OS: Process %d set in READY state\n", 
                                  timeStr, interruptedProc->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            
            interruptedProc->intrpFlag = False;
            
            break;
           }

       }

    if( crtMdPtr->opValue == 0 && crtMdPtr->opLtr == 'P' )
       {
        // printf "run operation end"
        strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "end" , logToCode );
        
        if( configDataPtr->cpuSchedCode == CPU_SCHED_FCFS_P_CODE
           || configDataPtr->cpuSchedCode == CPU_SCHED_SRTF_P_CODE
           || configDataPtr->cpuSchedCode == CPU_SCHED_RR_P_CODE )
           {
            sprintf( buffer, "\n");
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
           }
        
        // set current process to READY state
           // function name: setProcState()
        setProcState( crtPCBPtr, READY_STATE );
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Process %d set in READY state\n", 
                                  timeStr, procId);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

    
        // display the updated remaining time
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    
        setProcState( crtPCBPtr, RUNNING_STATE );
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n", 
                                  timeStr, procId);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       }

        crtPCBPtr->crtMdNode= crtMdPtr;
    
        // return strBfrPtr
        return strBfrPtr;
   }


/*
Function name: checkProcInStates
*/
Boolean checkProcInStates( PCBType *PCBHeadPtr, 
                   int destStateOne, int destStateTwo )
   {
    // initialize temporary pointer
    PCBType *tempPtr = PCBHeadPtr;
    
    while( tempPtr != NULL )
       {
        // if one of the process's state is not the destState,
        // return False
        if( tempPtr->state != destStateOne && tempPtr->state != destStateTwo )
           {
            return False;
           }
        
        // go to next pointer;
        tempPtr = tempPtr->next;
       }
       
    // otherwise, return True
    return True;
   }  
   
/*
Function name: pthreadPreemption
*/
void pthreadPreemption( ThreadType *threadNode )
   {
    
    // define thread reference variables
    pthread_t thread;

    // create pthreads
    pthread_create( &thread, NULL, ioPreemptiveFnct, threadNode );
    
   }

/*
Function name: ioPreemptiveFnct
               rewrite runTimer()
*/
void *ioPreemptiveFnct( void *param )
   {
    // initialize variables
       
       ThreadType *tempTrdPtr = (ThreadType *) param;
       
       PCBType *crtPCBPtr = tempTrdPtr->PCBNode;

       int cycleTime = tempTrdPtr->ioCycleTime;
    
    // Call tunTimer to fake the process time
    runTimer(cycleTime);
    
    // update the remaining time of the process
    crtPCBPtr->runTime -= tempTrdPtr->ioCycleTime;

    crtPCBPtr->intrpFlag = True;
    
    // free the memory space
    free(tempTrdPtr);
    
    pthread_exit( NULL );
   }

/*
Function name: isPreemptive
Description: check if the scheduler is preemptive
*/
Boolean isPreemptive( ConfigDataType *configDataPtr )
   {
    // initialize variables
    
    int scheduler = configDataPtr->cpuSchedCode;
    
    if( scheduler == CPU_SCHED_SRTF_P_CODE 
        || scheduler == CPU_SCHED_FCFS_P_CODE
        || scheduler == CPU_SCHED_RR_P_CODE )
       {
        return True;
       }
    
    // otherwise, return False
    return False;
   }


/*
Function name:findReadyProc
Description: find next process which are in ready state
*/
PCBType *findReadyProc( PCBType *PCBHeadPtr)
   {
    // initialize variables
       
       // temp for curretn PCB node
       PCBType *crtPCBPtr = PCBHeadPtr;
    
    while( crtPCBPtr->state != READY_STATE && crtPCBPtr != NULL )
       {
        crtPCBPtr = crtPCBPtr->next;
       }
    
    if( crtPCBPtr->state == READY_STATE )
       {
        return crtPCBPtr;
       }
    
    return NULL;
   }

/*
Function name: isInterrupt
Description: check if process of PCB list interrupts
*/
Boolean isInterrupt( PCBType *PCBHeadPtr )
   {

    // if find a process whose intrpFlag is True, return true
    if( findIntrpProc( PCBHeadPtr ) != NULL )
       {
        return True;
       }
    
    // otherwise, return False
    return False;
   }

/*
Function name: findIntrpProc
*/
PCBType *findIntrpProc( PCBType *PCBHeadPtr )
   {
    // initialize variables
    PCBType *crtPCBPtr = PCBHeadPtr;
    
    while( crtPCBPtr != NULL )
       {
        // when intrpFlag is True, return true
        if( crtPCBPtr->intrpFlag == True )
           {
            return crtPCBPtr;
           }
        
        crtPCBPtr = crtPCBPtr->next;
        
       }
    
    // otherwise, return NULL
    return NULL;
   }

/*
Function name: numOfProcInReady
*/
int numOfProcInReady( PCBType *PCBHeadPtr )
   {
    PCBType *localPtr = PCBHeadPtr;
    
    int index = 0;
    
    while( localPtr != NULL )
       {
        if( localPtr->state == READY_STATE )
           {
            index++;
           }
        localPtr = localPtr->next;
       }

    return index;
   }
   
  
/*
isInState( PCBHeadPtr, RUNNING_STATE )
*/
Boolean isInState( PCBType *PCBHeadPtr, int State )
   {
    PCBType *tempPtr = PCBHeadPtr;
    while( tempPtr != NULL )
       {
        if( tempPtr->state == State )
           {
            return True;
           }
        tempPtr = tempPtr->next;
       }
       
    return False;
   }































