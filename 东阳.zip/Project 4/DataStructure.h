// precompiler directives
#ifndef DATASTRUCTURE_H
#define DATASTRUCTURE_H


// global constants
typedef enum { 
               DEFAULT_STATE,
               NEW_STATE,
               READY_STATE,
               RUNNING_STATE,
               EXIT_STATE,
               BLOCKED_STATE } ProcState;
     
typedef enum { 
               NOT_OP,
               FOUND_OP} OpManipCode;
               

typedef struct PCBType
   {
    int state;
    int procId;
    int runTime;
    
    Boolean intrpFlag; // flag to indicate if the process is bolcked
    
    OpCodeType *crtMdNode; // points to the node running to the current opCode of the current process
    
    OpCodeType *headMdPtr; // points to the first opCode of the whoe PCB linked list
    
    long memAvailable;  // the total memory authorized
    
    struct MMUType *mmuUnit;
    
    struct MMUType *MMUList;
    
    struct PCBType *next;
   } PCBType;

typedef struct ThreadType
   {
    int ioCycleTime;
    struct PCBType *PCBNode;

    ConfigDataType *configDataPtr;
    char *timeStr;
    
   } ThreadType;


typedef struct StrBufferType
   {
    char strBuffer[ 100 ];
    struct StrBufferType *next;
   } StrBufferType;
   

typedef struct MMUType
   {
    long memAuth;
    long memAllocStart; // the memory allcated
    long memAllocEnd;
    long memAccStart;   // for an memory access request
    long memAccEnd;
    
    // next pointer
    struct MMUType *next;
    
   } MMUType;

































// end directives
#endif



