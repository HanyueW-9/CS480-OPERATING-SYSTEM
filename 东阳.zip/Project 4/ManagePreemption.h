// precompiler directives
#ifndef MANAGEPREEMPTION_H
#define MANAGEPREEMPTION_H

// header file
#include "SimAccess.h"
#include <stdio.h>
#include "MetaDataAccess.h"
#include "Simtimer.h"
#include "StringUtils.h"
#include "ConfigAccess.h"
#include <pthread.h>
#include "DataStructure.h"


/*
typedef struct PCBType PCBType;
typedef struct MMUType MMUType;
typedef struct StrBufferType StrBufferType;
typedef struct ThreadType ThreadType;
*/

// function prototype
void opCodePreemptAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                     PCBType *PCBHeadPtr, char *timeStr,
                     StrBufferType *strBfrPtr);
void clearPCB_MMU( PCBType *crtPCBPtr );

Boolean checkAllProcState( PCBType *PCBHeadPtr, int destState );

StrBufferType *runOpCode_P_preempt( ConfigDataType *configDataPtr, char *timeStr,
                              StrBufferType *strBfrPtr,
                             PCBType **crtPCBPtr, PCBType *PCBHeadPtr,
                             OpCodeType *crtMdPtr);

Boolean checkProcInStates( PCBType *PCBHeadPtr, 
                   int destStateOne, int destStateTwo );

void pthreadPreemption( ThreadType *threadNode );
void *ioPreemptiveFnct( void *param );

Boolean isPreemptive( ConfigDataType *configDataPtr );
Boolean isInterrupt( PCBType *PCBHeadPtr );
PCBType *findIntrpProc( PCBType *PCBHeadPtr );


PCBType *findReadyProc( PCBType *PCBHeadPtr);

int numOfProcInReady( PCBType *PCBHeadPtr );

Boolean isInState(  PCBType *PCBHeadPtr, int State );






































// end directives
#endif
