// header
#include <stdio.h>
#include "ConfigAccess.h"
#include "MetaDataAccess.h"

/*
Function: main
algorithm: driver function for combining the configdata and 
           metadata access operations
Precondition: none
PostCondition: returns 0 on success
Eceptions: none
Notes: none
*/
int main( int argc, char **argv )
  {
  // initialize
  int configAccessResult, mdAccessResult;
  char configFileName[ MAX_STR_LEN ];
  char mdFileName[ MAX_STR_LEN ];
  ConfigDataType *configDataPtr;
  OpCodeType *mdData;
  
  // display component title
  printf("\nConfig File Upload Component\n" );
  printf("================================\n\n" );
  
  //check for not correct number of command line arguments
  if( argc < 2 )
    {
    // print missing command line argument error
    printf( "ERROR: Program requires file name for config file " );
    printf( "as command line argument\n" );
    printf( "Program Terminated\n" );
    // return non normal result
    return 1;
    }
    
    // get data from configuration file
    copyString( configFileName, argv[ 1 ] );
    configAccessResult = getConfigData( configFileName, &configDataPtr );
    
    // check for successful config upload
    if( configAccessResult == NO_ERR )
      {
      // display config data
      displayConfigData( configDataPtr );
      }
    
    // otherwise assume failed config upload
    else
      {
      // display error
      displayConfigError( configAccessResult );
      }
      
    // display meta data component title
    printf( "\nMeta Data File Upload Component\n" );
    printf( "===================================\n" );
    
    // get meta data using file name from config file
    copyString( mdFileName, configDataPtr->metaDataFileName );
    mdAccessResult = getOpCodes( mdFileName, &mdData );
    
    // check for successful meta data upload
    if( mdAccessResult == NO_ERR )
      {
      // display meta data
      displayMetaData( mdData );
      }
      
    // otherwise assume failed upload
    else
      {
      // display meta data error
      displayMetaDataError( mdAccessResult );
      }
      
    // shutdown and close program
    
      // clear config data
      clearConfigData( &configDataPtr );
    
      // clear meta data 
      mdData = clearMetaDataList( mdData );
    
      // prints close line
      printf("\n");
    
      // return success
      return 0;
    
  }
    
      
