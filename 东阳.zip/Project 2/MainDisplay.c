// header
#include <stdio.h>
#include "ConfigAccess.h"
#include "MetaDataAccess.h"
#include "SimAccess.h"

/*
Function: main
algorithm: driver function for combining the configdata and 
           metadata access operations
Precondition: none
PostCondition: returns 0 on success
Eceptions: none
Notes: none
*/
int main( int argc, char **argv )
  {
  // initialize
  int configAccessResult, mdAccessResult;
  char configFileName[ MAX_STR_LEN ];
  char mdFileName[ MAX_STR_LEN ];
  ConfigDataType *configDataPtr;
  OpCodeType *mdData;
  
  // new variables
  char simClock[ STD_STR_LEN ];
  
  
  // display the main title
  printf("\nSimulator Program\n");
  printf("=================\n\n");
  
  // display component title
  printf("Uploading Configuration Files\n" );
  
  //check for not correct number of command line arguments
  if( argc < 2 )
    {
    // print missing command line argument error
    printf( "ERROR: Program requires file name for config file " );
    printf( "as command line argument\n" );
    printf( "Program Terminated\n" );
    
    // return non normal result
    return 1;
    }
    
    // get data from configuration file
    copyString( configFileName, argv[ 1 ] );
    configAccessResult = getConfigData( configFileName, &configDataPtr );
    
    // check for failed config upload
    if( configAccessResult != NO_ERR )
      {
       // display error
       displayConfigError( configAccessResult );
       
       printf("\nEnd Simulation - terminated\n");
       printf("=========================\n\n");
       // return non normal result
       return 1;
      }
      
    // display meta data component title
    printf( "\nUploading Meta Data Files\n\n" );
    
    // get meta data using file name from config file
    copyString( mdFileName, configDataPtr->metaDataFileName );
    mdAccessResult = getOpCodes( mdFileName, &mdData );
    
    // check for failed meta data upload
    if( mdAccessResult != NO_ERR )
      {
       // display meta data error
       displayMetaDataError( mdAccessResult );
       
       printf("\nEnd Simulation - terminated\n");
       printf("=========================\n\n");
       // return non normal result
       return 1;
      }
        
    // access opCommands from metaData file
    // function: runProg
    runProg( configDataPtr, mdData, simClock );
    
    // shutdown and close program
    
      // clear config data
      clearConfigData( &configDataPtr );
    
      // clear meta data 
      mdData = clearMetaDataList( mdData );
    
    
      // return success
      return 0;
    
  }
    
      
