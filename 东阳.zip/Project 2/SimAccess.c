// header files
#include "SimAccess.h"

/*
Function name: runProg
Description: major function to run the program
*/
void runProg( ConfigDataType *configDataPtr, OpCodeType *mdPtr,  char *timeStr )
   {
    // initialize function/variables
    
        // initialize tempMdPtr
        OpCodeType *tempMdPtr = mdPtr ;
        
        // initialize counter for the number of processes
        int procCounter = 0;
        
        // initialize the head pointer of PCB
        PCBType *PCBHeadPtr = NULL;
        
        // initialize the sign of where to log
        int logToCode = configDataPtr->logToCode;
        
        // initialize the buffer of a string stored
        char buffer[ MAX_STR_LEN ];
        
        // initialize the link list of the buffer
        StrBufferType *strBfrPtr = NULL;
    
    // store Log File Header info to file
        // function: storeHeader
    strBfrPtr = storeHeader( strBfrPtr, configDataPtr );
    
    // display (or not) simulation component title
    // store buffer to a link list (output)
        // function: outputManager
    sprintf( buffer, "=================\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

    sprintf( buffer, "Begin Simulation\n\n" );
    
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
    // get the opLtr (check if it's S(start))
    if( tempMdPtr->opLtr == 'S'
        && compareString( tempMdPtr->opName, "start" ) == STR_EQ )
       {
        
        // start time 
        // function: accessTimer
        accessTimer( ZERO_TIMER, timeStr );
        
        // printf "OS: System Start"
        sprintf( buffer, "  %s, OS: System Start\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

        // create PCBs according to Applications from metaData file
            // function: getNumOfProcess
        procCounter = getNumOfProcess( tempMdPtr );
        
            // function: createPCB
        PCBHeadPtr = createPCB( PCBHeadPtr, procCounter );
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: Create Process Control Blocks\n", timeStr);
   	  strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
   	  
        // initialize all processes in New state
            // function: setAllProcState
        setAllProcState( PCBHeadPtr, NEW_STATE);
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: All processes initialized in New state\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // set all processes in Ready state
        setAllProcState( PCBHeadPtr, READY_STATE);
        
        accessTimer( LAP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: All processes now set in Ready state\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
       
        // go to next pointer
        tempMdPtr = tempMdPtr->next;
        
        // manipulate I/O/P operation commands
        opCodeAccess( configDataPtr, tempMdPtr, PCBHeadPtr, timeStr, strBfrPtr );

        // clear the PCB list
        clearPCBList( PCBHeadPtr );
        
        // printf "System stop"
        accessTimer( STOP_TIMER, timeStr );
        sprintf( buffer, "  %s, OS: System stop\n", timeStr);
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // display the message that complete the simulation
        sprintf( buffer, "\nEnd Simulation - Complete\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        sprintf( buffer, "===========================\n");
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
        // add endline for vertical spacing
        sprintf( buffer, "\n" );
        strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
        
       }
   
   // check if output data to file
   if( logToCode == LOGTO_FILE_CODE || logToCode == LOGTO_BOTH_CODE )
      {
       // initialize a variable for file name
       char *logToFileName = configDataPtr->logToFileName;
       
       storeFile( logToFileName, strBfrPtr );
       
       if( logToCode == LOGTO_FILE_CODE )
          {
           // display successfully to make it user friendly
           printf( "End Simulation - Complete\n" );
           
           printf( "===========================\n");
          }
      }
   
   // clear strBfrPtr data
   strBfrPtr = clearStrBfrList( strBfrPtr );
   
   }

/*
Function name: opCodeAccess
Description: manipulate op code
*/
void opCodeAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
             PCBType *PCBHeadPtr, char *timeStr, StrBufferType *strBfrPtr)
   {
    // initialize variables
        // for temp data
        OpCodeType *crtMdPtr = mdPtr; 
        
        // for current PCB pointer
        PCBType *crtPCBPtr = PCBHeadPtr;
        
        // initialize the sign of where to log
        int logToCode = configDataPtr->logToCode;
        
        // temp for configDataPtr->ioCycleRate
        int ioCycleRate = configDataPtr->ioCycleRate;
        
        // temp for configDataPtr->procCycleRate
        int procCycleRate = configDataPtr->procCycleRate;
        
        // total cycleTime for current operation
        int cycleTime;
        
        // initialize the buffer of a string stored
        char buffer[ STD_STR_LEN ];
        
        
        // result of whether the application program is found
        int appResult = isNewProc( crtMdPtr, DEFAULT_OP );
        
        while ( crtMdPtr->opLtr != 'S' )
          {
            // get next process: find opCommand is A(start)
                // function: findAppPtr
             // appResult = isNewProc( crtMdPtr, appResult );

            if( appResult == FOUND_OP )
               {
                // store operation time to PCB
                    // function: getTimeOfAProc
                crtPCBPtr->runTime = getTimeOfAProc( configDataPtr, crtMdPtr );
                
                // printf "Process 0 selected with 9650 ms remaining"
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d selected with %d ms remaining\n",
                              timeStr, crtPCBPtr->procId, crtPCBPtr->runTime );
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
                // set current Process  in RUNNING state"
                setProcState( crtPCBPtr, RUNNING_STATE );
                accessTimer( LAP_TIMER, timeStr );
                sprintf( buffer, "  %s, OS: Process %d set in RUNNING state\n\n", 
                                  timeStr, crtPCBPtr->procId);
                strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
                
                // go to next pointer, start runnning
                crtMdPtr = crtMdPtr->next;
               }
            
            // check if opLtr = 'P'
           if( crtMdPtr->opLtr == 'P' )
              {
               
               cycleTime = getCycleTime( procCycleRate, crtMdPtr->opValue);

               strBfrPtr = runOpCode_P( cycleTime, timeStr, logToCode, strBfrPtr, crtPCBPtr->procId, crtMdPtr);

              }
             
             // otherwise, check if opLtr = 'I'  
           else if( crtMdPtr->opLtr == 'I' || crtMdPtr->opLtr == 'O' )
              {
               runOpCode_IO( ioCycleRate, timeStr, logToCode,
                                     crtMdPtr, strBfrPtr, crtPCBPtr->procId );
              }
              
        // go to next opCommand
        crtMdPtr = crtMdPtr->next;
            
        // check if opCommand arrives at A(end)
        // then go to next PCB pointer
        if( crtMdPtr->opLtr == 'A'
              && compareString( crtMdPtr->opName, "end" ) == STR_EQ )
           {
            setProcState( crtPCBPtr, EXIT_STATE);
            
            accessTimer( LAP_TIMER, timeStr );
            sprintf( buffer, "\n  %s, OS: Process %d ended and set in EXIT state\n",
                                      timeStr, crtPCBPtr->procId);
            strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
            
            if( crtPCBPtr->next != NULL )
               {
                // go to next PCB node
                crtPCBPtr = crtPCBPtr->next;
               }
            
            // go to next opCommand
            crtMdPtr = crtMdPtr->next;
            
           }
        
        // get next process: find opCommand is A(start)
            // function: findAppPtr
        appResult = isNewProc( crtMdPtr, appResult );
           
       }
    
    // reference the mdDataPtr to crtMdPtr
    mdPtr = crtMdPtr;
   }

/*
Function name:runOpCode_P
Description: modular function, specifically check opLtr 'P'
*/
StrBufferType *runOpCode_P( int cycleTime, char *timeStr, int logToCode,
          StrBufferType *strBfrPtr, int procId, OpCodeType *crtMdPtr)
   {
    // initialize variables 

    strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "start" , logToCode );
    
    // simulate processing time
    // function: runTimer
    runTimer( cycleTime );
    
    // printf "run operation end"
    strBfrPtr = saveBuffer(strBfrPtr, timeStr, procId, crtMdPtr, "end" , logToCode );
    
    // return strBfrPtr
    return strBfrPtr;
   }

/*
Function name: runOpCode_IO
Description: modular function, specifically check input and output
*/
StrBufferType *runOpCode_IO( int ioCycleRate, char *timeStr, int logToCode,
                    OpCodeType *crtMdPtr, StrBufferType *strBfrPtr, int procId )
   {     
    strBfrPtr = saveBuffer( strBfrPtr, timeStr, procId,
                              crtMdPtr, "start", logToCode );
  
    // simulate processing time,
       // function: getCycleTime, runTimer, getCycleTime
    int cycleTime = getCycleTime( ioCycleRate, crtMdPtr->opValue);
  
    // call pthread
    pthreadAccess( cycleTime );
  
    strBfrPtr = saveBuffer( strBfrPtr, timeStr, procId,
                              crtMdPtr, "end", logToCode );
                              
    return strBfrPtr;
   }


/*
Function name: saveBuffer
Description: save them to buffer or not according to logToCode
*/
StrBufferType *saveBuffer(StrBufferType* strBfrPtr, char *timeStr,
               int procId, OpCodeType *crtMdPtr, char *flag , int logToCode )
   {
    // initialize variables
    char buffer[ STD_STR_LEN ];
    
    char opString[ MAX_STR_LEN ];
    
    copyString( opString, crtMdPtr->opName );
    
    // set a string according to opLtr
    switch (crtMdPtr->opLtr)
       {
        case 'I': 
           concatenateString( opString, " input ");
           break;
        case 'O':
           concatenateString( opString, " output ");
           break;
        case 'P':
           concatenateString( opString, " operation ");
           break;
       }    


    concatenateString( opString, flag);
    
    // keep time
    accessTimer( LAP_TIMER, timeStr );
    
    sprintf( buffer, "  %s, Process %d, %s\n",
                                   timeStr, procId, opString);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    

    return strBfrPtr;
   }

/*
Function name: pthreadAccess
*/
void pthreadAccess( int cycleTime )
   {
    // define thread reference variables
    pthread_t thread;

    // create pthreads
    pthread_create( &thread, NULL, entryFunction, &cycleTime );
         
    // join ecerything back up
    pthread_join( thread, NULL);
   }

/*
Function name:clearStrBfrList
*/
StrBufferType *clearStrBfrList( StrBufferType *localPtr )
   {
    // check for local pointer not set to null (list not empty)
    if( localPtr != NULL )
       {
        // check for local pointer's next node not null
        if( localPtr->next != NULL )
           {
            // call recursive function with next pointer
                // function: clearStrBfrList
            clearStrBfrList( localPtr->next );
           }
           
        // after recursive call, release memory to OS
            // function: free
        free( localPtr );
       }
       
    // return null to calling function
    return NULL;
   }
/*
Function name: storeHeader
Description: store config data into the object file 
*/
StrBufferType *storeHeader( StrBufferType *strBfrPtr, ConfigDataType *configPtr )
   {
    // initialize variables
    
        // initialize the buffer of a string stored
        char buffer[ MAX_STR_LEN ];
        
        char displayString[ STD_STR_LEN ];
    
        int logToCode = LOGTO_FILE_CODE;
        
    sprintf( buffer, "==================================================\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    
    sprintf( buffer, "Simulator Log File Header\n\n" );
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );

    sprintf( buffer, "File Name                       : %s\n", 
                                  configPtr->metaDataFileName);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    configCodeToString( configPtr->cpuSchedCode, displayString );

    sprintf( buffer, "CPU Scheduling                  : %s\n", 
                                                displayString);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Quantum Cycles                  : %d\n", 
                                  configPtr->quantumCycles);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Memory Available (KB)           : %ld\n", 
                                  configPtr->memAvailable);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "Processor Cycle Rate (ms/cycle) : %d\n", 
                                  configPtr->procCycleRate);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    sprintf( buffer, "I/O Cycle Rate (ms/cycle)       : %d\n\n", 
                                  configPtr->ioCycleRate);
    strBfrPtr = outputManager( strBfrPtr, buffer, logToCode );
    
    // return head pointer
    return strBfrPtr;
   }


/*
Function name: storeFile
Description: store the string buffer link list to the object file
*/
void storeFile( char *fileName, StrBufferType *headBfrPtr )
   {
    // initialize a loacl pointer pointint to the head pointer
    StrBufferType *localPtr = headBfrPtr;
    
    
    // create file named fileName in write mode
    FILE *fptr = fopen( fileName, "w" );
    
    
    // traverse the link list
    while( localPtr != NULL )
       {
        fprintf( fptr, localPtr->strBuffer );
        
        // go to next pointer
        localPtr = localPtr->next;
       
       }

    // close file
    fclose( fptr );
    
   }


/*
Function Name: outputManager
Description: decide if output info to monitor according to logToCode
*/
StrBufferType *outputManager( StrBufferType *bfrHeadPtr, char *string, int logToCode )
   {
    // initialize temporary pointer of StrBufferType
    StrBufferType *newPtr = NULL;
    
    // access memory for new link/node
    newPtr = (StrBufferType *) malloc(sizeof( StrBufferType ));
    
    // assign all values to newly created node
    copyString( newPtr->strBuffer, string );
    // newPtr->strBuffer = string;  // Michael
    
    // assign next pointer to NULL
    newPtr->next = NULL;
    
    // create the link list
    bfrHeadPtr = linkBufferList( bfrHeadPtr, newPtr );

    // check if output the string
    if( logToCode == LOGTO_MONITOR_CODE || logToCode == LOGTO_BOTH_CODE )
       {
        printf( "%s", string );
       }
    
    // return head pointer
    return bfrHeadPtr;
   }

/*
Function name: linkBufferList
*/
StrBufferType *linkBufferList( StrBufferType *headPtr,
                                          StrBufferType *newNode )
   {
    // initialize  a current pointer
    StrBufferType *localPtr = NULL;
    
    // initialize  a current pointer
    StrBufferType *tempPtr = newNode;
    
    // check if headPtr is undefined
    if( headPtr == NULL )
       {
        // set headPtr to newNode;
        headPtr = tempPtr;
        
        // return head pointer
        return headPtr;
       }
    
    localPtr = headPtr;
    
    // otherwise
    while( localPtr->next != NULL )
       {
        // go to next pointer until at the end of the list
        localPtr = localPtr->next;
       }

    // set local's next pointer to newNode
    localPtr->next = tempPtr;

    // return head pointer 
    return headPtr;
   }
   

/*
Function name: isNewProc
Description: check if there is a new process coming in
*/
int isNewProc( OpCodeType* localPtr, int result )
   {
    // initialize temp pointer
    OpCodeType *tempPtr = localPtr;
    
    
    if( tempPtr->opLtr == 'A'
        && compareString( tempPtr->opName, "start" ) == STR_EQ )
       {
     
         // if A(start) has found before, then set result to FOUND_OP
         
         return FOUND_OP;
       }
       
    // otherwise, it's not a start of a new process;
    return NOT_OP;
   }


/*
Function name: setProcState
*/
void setProcState( PCBType *localPtr, ProcState destState )
   {    
    // set local pointer's state to destination
    localPtr->state = destState;
   }

/*
Function name: setAllProcState
*/
void setAllProcState( PCBType *localPtr, ProcState destState )
   {
    // initialize temporary pointer
    PCBType *tempPtr = localPtr;
    
    while( tempPtr != NULL )
       {
        // set local pointer's state to destination
        tempPtr->state = destState;
        
        // change the state of current Pointer
        setProcState( tempPtr, destState );
        
        // go to next pointer;
        tempPtr = tempPtr->next;
       }
   }

/*
Function Name: createPCB
*/
PCBType *createPCB( PCBType *headPtr, int ctrOfProc )
   {
    // initialize function/variables
    
        // initialize index of the loop
        int index;
        
        // initialize the temp pointer and current pointer
        PCBType *tempPtr = NULL;
        PCBType *localPtr = NULL;
        
    // create specific number of PCBs with respect to the counter of it
        // using loop
    for( index = 0; index < ctrOfProc; index++ )
       {
        // access memory for new link/node
            // function: malloc
        tempPtr = ( PCBType *) malloc( sizeof( PCBType ) );
         
        // assign all values to newly created node
        tempPtr->state = DEFAULT_STATE;
        tempPtr->procId = index;
        tempPtr->runTime = 0;
        // assign next pointer to null
        tempPtr->next = NULL;
        
        
        // check if headPtr is uninitialized
        if( headPtr == NULL )
           {
            // set headPtr to tempPtr
            headPtr = tempPtr;
            localPtr = tempPtr;
           }
        // check if headPtr and local are same
        // then link headPtr's next to the tempPtr
        else if( headPtr == localPtr )
           {
            // set localPtr to tempPtr
            localPtr = tempPtr;
            
            // set head's next pointer to localPtr
            headPtr->next = localPtr;
           }
        // otherwise
        else
           {
            // set local's next pointer to temp
            localPtr->next = tempPtr;
           }
       }
       
    // return current local pointer
    return headPtr;
   }

/*
Function Name: getNumOfProcess
*/
int getNumOfProcess( OpCodeType *localPtr )
   {
    // create variable for counter
    int counter = 0;
    
    // temp for process pointer
    OpCodeType *tempPtr = localPtr;
    
    // iterate through the link list
    while( tempPtr != NULL )
       {
        // if opLtr is 'A' and opName is "start"
        if( tempPtr->opLtr == 'A' 
            && compareString( tempPtr->opName, "start" ) == STR_EQ )
           {
            // increment the counter
            counter++;
           }
        
        // go to next pointer
        tempPtr = tempPtr->next;
       }
       
    // return the number of processes
    return counter;
    
   }

   
/*
Function name: entryFunction
               rewrite runTimer()
*/
void *entryFunction( void *param )
   {
    
    int cycleTime = *( (int *) param);
    
    // Call tunTimer to fake the process time
    runTimer(cycleTime);
    
    // stud return value
    return NULL;
   }

/*
Function name: getTimeOfAProc
*/
int getTimeOfAProc( ConfigDataType *configDataPtr, OpCodeType *mdPtr )
   {
    
    // initialize variables
        // for temp data
        OpCodeType *crtMdPtr = mdPtr;
        
        // temp for configDataPtr->ioCycleRate
        int ioCycleRate = configDataPtr->ioCycleRate;
        
        // temp for configDataPtr->procCycleRate
        int procCycleRate = configDataPtr->procCycleRate;
    
        // for sum of time remaining
        int sumTime = 0;
    
    // loop the link list
    while( crtMdPtr != NULL )
       {
        
        // check if opLtr is P, I, or O
        switch( crtMdPtr->opLtr )
           {
            case 'P':
               sumTime += crtMdPtr->opValue * procCycleRate;
               break;
               
            case 'I':
            case 'O':
               sumTime += crtMdPtr->opValue * ioCycleRate;
               break;
           }
        
        // go to next link
        crtMdPtr = crtMdPtr->next;
        
        // check if crtMdPtr->opLtr is 'A' and opName is "end"
        // or opLtr is 'S'
        // which means one process gets done
        // then return sumTime
        if( ( crtMdPtr->opLtr == 'A'
              && compareString( crtMdPtr->opName, "end" ) == STR_EQ )
            || crtMdPtr->opLtr == 'S' )
           {
            return sumTime;
           }
       }
    
    // complete traverse
    return sumTime;
   }

/*
Function name: getCycleTime
Precondition: pass cycleRate and opValue of a certain operation
Postcondition: return the total time consisting of the multiplication
               of cycleRate * opValue 
*/
int getCycleTime( int cycleRate, int opValue)
   {
    return (cycleRate * opValue);
   }

/*
Function name: clearPCBList
*/
PCBType *clearPCBList( PCBType *localPtr )
   {
    // check for local pointer not set to null (list not empty)
    if( localPtr != NULL )
       {
        // check for local pointer's next node not null
        if( localPtr->next != NULL )
           {
            // call recursive function with next pointer
                // function: clearPCBList
            clearPCBList( localPtr->next );
           }
        
        // after recursive call, release memory to OS
        free( localPtr );
       }

    // return null to calling function
    return NULL;
   }


   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
