// precompiler directives
#ifndef SIMACCESS_H
#define SIMACCESS_H

// header file
#include <stdio.h>
#include "Simtimer.h"
#include "MetaDataAccess.h"
#include "StringUtils.h"
#include "ConfigAccess.h"
#include <pthread.h>

// global constants
typedef enum { 
               DEFAULT_STATE,
               NEW_STATE,
               READY_STATE,
               RUNNING_STATE,
               EXIT_STATE } ProcState;
     
typedef enum { DEFAULT_OP,
               NOT_OP,
               FOUND_OP} OpManipCode;
               

typedef struct PCBType
   {
    int state;
    int procId;
    int runTime;
    struct PCBType *next;
   } PCBType;

typedef struct StrBufferType
   {
    char strBuffer[ 100 ];
    struct StrBufferType *next;
   } StrBufferType;



// function prototype
void runProg( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                     char *timeStr );
void opCodeAccess( ConfigDataType *configDataPtr, OpCodeType *mdPtr,
                      PCBType *PCBHeadPtr, char *timeStr,
                        StrBufferType *strBfrPtr);

StrBufferType *runOpCode_P( int cycleTime, char *timeStr,
   int logToCode, StrBufferType *strBfrPtr, int procId, OpCodeType *crtMdPtr );

StrBufferType *saveBuffer(StrBufferType* strBfrPtr, char *timeStr,
               int procId, OpCodeType *crtMdPtr, char *flag , int logToCode );
               
void pthreadAccess( int cycleTime );

StrBufferType *runOpCode_IO( int ioCycleRate, char *timeStr, int logToCode,
                    OpCodeType *crtMdPtr, StrBufferType *strBfrPtr, int procId );
                  
int getTimeOfAProc( ConfigDataType *configDataPtr, OpCodeType *mdPtr );
int getCycleTime( int cycleRate, int opValue);
void *entryFunction( void *param );
PCBType *createPCB( PCBType *localPtr, int ctrOfProc );
int getNumOfProcess( OpCodeType *localPtr );


void setProcState( PCBType *localPtr, ProcState destState );
void setAllProcState( PCBType *localPtr, ProcState destState );


PCBType *clearPCBList( PCBType *localPtr );

int isNewProc( OpCodeType* localPtr, int result );

StrBufferType *outputManager( StrBufferType *bfrHeadPtr, char *string, int logToCode );
void storeFile( char *fileName, StrBufferType *headBfrPtr );
StrBufferType *linkBufferList( StrBufferType *bfrHeadPtr,
                                          StrBufferType *newNode );
StrBufferType *storeHeader( StrBufferType *headBfrPtr, ConfigDataType *configPtr );
StrBufferType *clearStrBfrList( StrBufferType *localPtr );

// end derectives
#endif

