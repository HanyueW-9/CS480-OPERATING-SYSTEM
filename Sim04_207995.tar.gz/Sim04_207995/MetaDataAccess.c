// header files
#include "MetaDataAccess.h"

// define constant from header
const int BAD_ARG_VAL = -1;

/*
Function Name: addNode
Algorithm: adds op command structure with data to a linked list
Precondition: linked list pointer assigned to null or to one op command link,
        structue pointer assigned to op command struct data
Postcondition; assigns new structuree node to beginning of linked list
        or an estableshed linked list
Exceptions: none
Notes: assumes memory acces/avaliability
*/
OpCodeType *addNode( OpCodeType* localPtr, OpCodeType* newNode )
{
    // check for local pointer assigned to null
    if( localPtr == NULL )
    {
        // access memory for new link/node
        localPtr = (OpCodeType* )malloc( sizeof( OpCodeType));

        // assign all three values to newly created node
        // assign next pointer to null
        localPtr->pid = newNode->pid;
        copyString( localPtr->command, newNode->command );
        copyString( localPtr->inOutArg, newNode->inOutArg );
        copyString( localPtr->strArg1, newNode->strArg1 );
        localPtr->intArg2 = newNode->intArg2;
        localPtr->intArg3 = newNode->intArg3;
        localPtr->opEndTime = newNode->opEndTime;

        localPtr->nextNode = NULL;
        
        // return current local pointer
        return localPtr;
    }

    // assume end of list not found yet
    // assign recuresive function to current's next linke
    localPtr->nextNode = addNode( localPtr->nextNode, newNode );

    // return current local pointer
    return localPtr;
}


/*
Function Name: clearMetaDataList
Algorithm: recursively iterates through op code linked list, 
           returns memory to OS from the bottom of the list upward
Precondition: linked list, with ot without data
Postcondition: all node memory, if any, is returned to OS, 
               return pointer (head) is set to null
Exceptions: none
Notes: none
*/
OpCodeType* clearMetaDataList (OpCodeType* localPtr )
{
    // check for local pointer not set to null (list not emptt)
    if( localPtr != NULL )
    {
        // ccheck for local pointer's next node not null
        if( localPtr->nextNode != NULL)
        {
            // call recursive function with next ointer
            clearMetaDataList( localPtr->nextNode );
        }

        // after recursive call, release memory to OS
        free( localPtr );
        localPtr = NULL;
    }
    
    // return null to calling function
    return NULL;
}


/*
Function Name: displayMetaData
Algorithm: iterates through op code linked list, 
           displays op code data individually
Precondition: linked list, with or without data
              (should not be called if no data)
Postcondition: displays all opcodes in list
Exceptions: none
Notes: none
*/
void displayMetaData( OpCodeType* localPtr )
{
    // display title, with underline
    printf( "\nMeta-Data File Display\n" );
    printf( "=======================\n\n" );

    // loop to end of linked list
    while( localPtr != NULL)
    {
        // print op code leader:
        printf( "Op Code :  ");

        // print op code parts
        printf( "pid %d", localPtr->pid );

        printf("/cmd: %s", localPtr->command );

        // check for devop command
        if( compareString( localPtr->command, "dev" ) == STR_EQ )
        {
            printf("/io: %s", localPtr->inOutArg );
        }

        else
        {
            printf("/io: NA" );
        }

        printf("\n\t /arg1: %s", localPtr->strArg1 );

        printf("/arg 2: %d", localPtr->intArg2 );

        printf("/arg 3: %d", localPtr->intArg3);

        printf("/op end time: %8.6f", localPtr->opEndTime );

        printf("\n\n");


        // assign local pointer to next node
        localPtr = localPtr->nextNode;
    }
}


/*
Function Name: getCommand
Algorithm: gets first three letters of input string to get command
Precondition: provide starting index
Postcondition: returns command (ref param) and updated index (return)
Exceptions: none
Notes: none
*/
int getCommand( char *cmd, char *inputStr, int index )
{
    // initialize variables
    int lengthOfCommand = 3;

    // loop across command lengths
    while( index < lengthOfCommand )
    {
        // assign character form input to buffer
        cmd[index] = inputStr[index];

        // increment index
        index++;

        // set next char to null
        cmd[index] = NULL_CHAR;
    }
    
    return index;
}


/*
Function Name: getMetaData
Algorithm: opens file, acquires op code data, 
           returns pointer to head of linked list
Precondition: for correct operation, file is available, is formatted
              correctly, and has all correctly formed op codes
Postcondition: in correct operation, return pointer to head of
               op code linked list
Exceptions: correctly and appropriately (without program failure)
            responds to and reports file access failure, 
            incorrectly formatted lead or end descriptors, 
            incorrectly formatted prompt, incorrect op code letter, 
            incorrect op code name, op code value out of range, 
            and incomplete file conditions
Notes: none
*/
Boolean getMetaData( char* fileName, OpCodeType** opCodeDataHead,
                                            char *endStateMsg)
{
    // initialize function/variables

        // initialize read only constant
        const char READ_ONLY_FLAG[] = "r";

        // initialize start and end counts for balanced app operations
        int startCount = 0, endCount = 0;

        // initialize local head pointer to null
        OpCodeType *localHeadPtr = NULL;

        // initialize variables
        int accessResult;
        char dataBuffer[ MAX_STR_LEN ];
        OpCodeType *newNodePtr;
        FILE *fileAccessPtr;
        Boolean stopAtNonPrintable = True;
        Boolean returnState = True;

    // initialize op code data pointer in case of return error
    *opCodeDataHead = NULL;

    // initialize end state message
    copyString( endStateMsg, "Metadata file upload successful" );

    // open file for reading
    fileAccessPtr = fopen( fileName, READ_ONLY_FLAG );

    // check for file open failure
    if( fileAccessPtr == NULL )
    {
        // return file access error
        copyString( endStateMsg, "Metadata file access error");
        return False;
    }

    // check first line for correct learder
    if( getLineTo( fileAccessPtr, MAX_STR_LEN, COLON,
                                dataBuffer, IGNORE_LEADING_WS, stopAtNonPrintable ) != NO_ERR
        || compareString( dataBuffer, "Start Program Meta-Data Code" ) != STR_EQ )
        {
            // close file
            fclose( fileAccessPtr );

            // return corrupt descriptor error
            copyString( endStateMsg, "Corrupt metadata leader line error" );
            return False;
        }

        // alocate memory for the temporary data structure
        newNodePtr = ( OpCodeType * )malloc( sizeof( OpCodeType ) );

        // get the first op command
        accessResult = getOpCommand( fileAccessPtr, newNodePtr );

        // get start and end counts for later comparison
        startCount = updateStartCount( startCount, newNodePtr->strArg1 );
        endCount = updateEndCount( endCount, newNodePtr->strArg1 );

        // check for failure of first complete op command
        if( accessResult != COMPLETE_OPCMD_FOUND_MSG )
        {
            // close file
            fclose( fileAccessPtr );

            // clear data from the structure list
            *opCodeDataHead = clearMetaDataList( localHeadPtr );

            // free temporary structure memory
            free( newNodePtr );

            // return result of operation
            copyString( endStateMsg, "Metadata incomplete first op command not found" );
            return False;
        }

        // loop across all remaining op commands
        //  (while complete op commands are found)
        while( accessResult == COMPLETE_OPCMD_FOUND_MSG )
        {
            // add the new op command to the linked list
            localHeadPtr = addNode( localHeadPtr, newNodePtr );

            // get a new op command
            accessResult = getOpCommand( fileAccessPtr, newNodePtr );

            // update start and end counts for later comparison
            startCount = updateStartCount( startCount, newNodePtr->strArg1 );
            endCount = updateEndCount( endCount, newNodePtr->strArg1 );
        }

        // after loop completion, check for last op command found
        if( accessResult == LAST_OPCMD_FOUND_MSG )
        {
            // check for start and end op code counts equal
            if( startCount == endCount )
            {
                // add the last node to the linked list
                localHeadPtr = addNode( localHeadPtr, newNodePtr );

                // set access result to no error for later operation
                accessResult = NO_ERR;

                // check last line for incorrect end descriptor
                if( getLineTo( fileAccessPtr, MAX_STR_LEN, PERIOD,
                                    dataBuffer, IGNORE_LEADING_WS, stopAtNonPrintable ) != NO_ERR
                    || compareString( dataBuffer, "End Program Meta-Data Code" )
                                                                                != STR_EQ )
                {
                    // set access result to corrupted descriptor error
                    accessResult = MD_CORRUPT_DESCRIPTOR_ERR;
                    copyString( endStateMsg, "Metadata corrupted descriptor error" );
                }
            }
        }
            
        // otherwise, assume didnt find end
        else
        {
            // set end state message
            copyString( endStateMsg, "Corrupted metadata op code" );
            returnState = False;
        }

        // check for any errors found (not no error)
        if( accessResult != NO_ERR )
        {
            // clear the op command list
                // function: clearMetaDataList
            localHeadPtr = clearMetaDataList( localHeadPtr );
        }

        // close access file
        fclose( fileAccessPtr );

        // release temporary structure memory
        free( newNodePtr );

        // assign temporary local head pointer to parameter return pointer
        *opCodeDataHead = localHeadPtr;

        // return access result
        return returnState;           
}


/*
Function Name: getOpCommand
Algorithm: acquires one op command, varifies all parts of it,
            returns as parameter
Precondition: file is open and file cursor is at beginning 
                of an op code
Postcondition: in correct operation,
                finds, tests, and returns op command as parameter,
                and returns status as integer
                - either complete op command found, or last op command found
Exceptions: correctly and appropriately (without program failure)
            responds to and reports file access failure,
            incorrectly formatted o command letter,
            incorrectly formatted op command name,
            incorrect or out of range op command value
Notes: none
*/
int getOpCommand( FILE* filePtr, OpCodeType* inData )
{
    // initialize function/variables

        // initialize local constants
        const int MAX_CMD_LENGTH = 5;
        const int MAX_ARG_STR_LENGTH = 15;

        // initialize other variables
        int accessResult, numBuffer = 0;
        char strBuffer[ STD_STR_LEN ];
        char cmdBuffer[ MAX_CMD_LENGTH ];
        char argStrBuffer[ MAX_ARG_STR_LENGTH ];
        int runningStringIndex = 0;
        Boolean stopAtNonPrintable = True;
        Boolean arg2FailureFlag = False;
        Boolean arg3FailureFlag = False;

    // get whole op command as a string
    accessResult = getLineTo( filePtr, STD_STR_LEN, SEMICOLON,
                                                strBuffer, IGNORE_LEADING_WS, stopAtNonPrintable );

    // check for successfull access
    if(accessResult == NO_ERR )
    {
        // get 3 letter command
        runningStringIndex = getCommand( cmdBuffer,
                                            strBuffer, runningStringIndex );

        // assing op command to node
        copyString( inData->command, cmdBuffer );
    }

    // otherwise, assume unsuccessful access
    else
    {
        // set pointer to data structure to null
        inData = NULL;

        // return op command access failure
        return OPCMD_ACCESS_ERR;
    }

    // varify op command valid
    if( verifyValidCommand( cmdBuffer ) == False )
    {
        return CORRUPT_OPCMD_ERR;
    }

    // set all struct values to defaults
    inData->pid = 0;
    inData->inOutArg[ 0 ] = NULL_CHAR;
    inData->intArg2 = 0;
    inData->intArg3 = 0;
    inData->opEndTime = 0.0;
    inData->nextNode = NULL;

    // check device command
    if( compareString( cmdBuffer, "dev" ) == STR_EQ )
    {
        runningStringIndex = getStringArg( argStrBuffer,
                                                    strBuffer, runningStringIndex );

        // set in/out arg
        copyString( inData->inOutArg, argStrBuffer );

        // check correct arg
        if( compareString( argStrBuffer, "in" ) != STR_EQ
                && compareString( argStrBuffer, "out" ) != STR_EQ )
        {
            return CORRUPT_OPCMD_ARG_ERR;
        }
    }

    // get first string arg
    runningStringIndex = getStringArg( argStrBuffer,
                                            strBuffer, runningStringIndex );

    // set device in/out arg
    copyString( inData->strArg1, argStrBuffer );

    // check for legit first string arg
    if( verifyFirstStringArg( argStrBuffer ) == False )
    {
        return CORRUPT_OPCMD_ARG_ERR;
    }

    // check for last op command found
    if( compareString( inData->command, "sys" ) == STR_EQ
                && compareString( inData->strArg1, "end" ) == STR_EQ )
    {
        return LAST_OPCMD_FOUND_MSG;
    }

    // check for app start seconds arg
    if( compareString( inData->command, "app" ) == STR_EQ
                        && compareString( inData->strArg1, "start" ) == STR_EQ )
    {
        runningStringIndex = getNumberArg( &numBuffer,
                                                strBuffer, runningStringIndex );
    

        // check failed num access
        if( numBuffer <= BAD_ARG_VAL )
        {
            arg2FailureFlag = True;
        }   
        
        // set first arg to number
        inData->intArg2 = numBuffer;
    }

    // check for cpu cycle time
    else if( compareString( inData->command, "cpu" ) == STR_EQ )
    {
        // get num arg
        runningStringIndex = getNumberArg( &numBuffer,
                                                strBuffer, runningStringIndex );
        
        // check failed num access
        if( numBuffer <= BAD_ARG_VAL )
        {
            arg2FailureFlag = True;
        }

        inData->intArg2 = numBuffer;
    }

    // check device cycle time
    else if( compareString( inData->command, "dev" ) == STR_EQ )
    {
        // get num arg
        runningStringIndex = getNumberArg( &numBuffer,
                                                strBuffer, runningStringIndex );
        
        // check failed num access
        if( numBuffer <= BAD_ARG_VAL )
        {
            arg2FailureFlag = True;
        }

        inData->intArg2 = numBuffer;
    }

    // check device memory base and offset
    else if( compareString( inData->command, "mem" ) == STR_EQ )
    {
        // get num arg
        runningStringIndex = getNumberArg( &numBuffer,
                                                strBuffer, runningStringIndex );
        
        // check failed num access
        if( numBuffer <= BAD_ARG_VAL )
        {
            arg2FailureFlag = True;
        }

        inData->intArg2 = numBuffer;
    

        // get num arg for offset
        runningStringIndex = getNumberArg( &numBuffer,
                                            strBuffer, runningStringIndex );

            // check failed num access
            if( numBuffer <= BAD_ARG_VAL )
            {
                arg3FailureFlag = True;
            }

        inData->intArg3 = numBuffer;
    }

    // check upload failure
    if( arg2FailureFlag == True || arg3FailureFlag == True )
    {
        return CORRUPT_OPCMD_ARG_ERR;
    }

    return COMPLETE_OPCMD_FOUND_MSG;
}


/*
Function Name: getNumberArg
Algorithm: skips leading white space
            acquires next integer from op command input string
            ending at comma or eos
Precondition: input string has some remaining string argument
Postcondition: in correct operation,
            captures next integer argument,
            returns index location after process finished
Exceptions: none
Notes: none
*/
int getNumberArg( int *number, char *inputStr, int index )
{
    // init function variables
    Boolean foundDigit = False;
    *number = 0;
    int multiplier = 1;

    // loop to skip white space (and comma)
    while( inputStr[ index ] <= SPACE || inputStr[ index ] == COMMA )
    {
        index++;
    }

    while( isDigit( inputStr[ index ] ) == True
                                        && inputStr[ index ] != NULL_CHAR )
    {
        // set flag
        foundDigit = True;


        // assign digit to output
        (*number) = (*number) * multiplier + inputStr[index] - '0';

        // increment index and multiplier
        index++;
        multiplier = 10;
    }
    // end loop across str length

    // check if digit not found
    if( foundDigit == False )
    {
        // set num to bad arg constant
        *number = BAD_ARG_VAL;
    }

    return index;
}

/*
Function Name: getStringArg
Algortihm: skips Leading white-space,
            aquires sub string from op command input string
            ending at comma or end of string
Precondition: input string has some remaining string argument
Postcondition: in correct operation,
            captures next string argument
Exceptions: none
Notes: none
*/
int getStringArg( char *strArg, char *inputStr, int index )
{
    // function variable initialization
    int localIndex = 0;

    // loop to skip white space (and comma)
    while( inputStr[ index ] <= SPACE || inputStr[ index ] == COMMA )
    {
        index++;
    }

    // loop across str length
    while( inputStr[ index ] != COMMA && inputStr[ index ] != NULL_CHAR )
    {
        // assign character from input string to buffer string
        strArg[ localIndex ] = inputStr[ index ];

        // increment indexes
        index++;
        localIndex++;

        // set next char to null
        strArg[ localIndex ] = NULL_CHAR;
    }
    // end loop across str length

    return index;
}


/*
Function Name: isDigit
Algorithm: checks for character digit, returns result
Precondition: test value is character
Postcondition: if test value is a value '0' < value < '9',
                returns true, otherwise returns false
Exceptions: none
Notes: none
*/
Boolean isDigit( char testChar )
{
    // check for test character between characters '0' - '9' inclusive
    if( testChar >= '0' && testChar <= '9' )
    {
        // return true
        return True;
    }

    // otherwise, assume character is not digit, return false
    return False;
}


/*
Function Name: updateEndCount
Algorithm: updates numer of "end" op commands found in file
Precondition: count >= 0, op string has "starendt" or other op name
Postcondition: if op string has "end", input count +1 is returned;
                otherwise, input count is returned unchanged
Exceptions: none
Notes: none
*/
int updateEndCount( int count, char* opString )
{
    // check for "end" in op string
        // function: compareString
    if( compareString( opString, "end" ) == STR_EQ )
    {
        // return incremented start count
        return count + 1;
    }
    
    // return unchanged start count
    return count;
}


/*
Function Name: updateStartCount
Algorithm: updates numer of "start" op commands found in file
Precondition: count >= 0, op string has "start" or other op name
Postcondition: if op string has "start", input count +1 is returned;
                otherwise, input count is returned unchanged
Exceptions: none
Notes: none
*/
int updateStartCount( int count, char* opString )
{
    // check for "start" in op string
        // function: compareString
    if( compareString( opString, "start" ) == STR_EQ )
    {
        // return incremented start count
        return count + 1;
    }
    
    // return unchanged start count
    return count;
}

/*
Function Name: varifyFirstStringArg
Algorithm: checks string argument for one of the allowed string args
Precondition: input string is provided
Postcondition: in correct operation,
            reports True if given string thats in arg list
            false if not
Exceptions: none
Notes: none
*/
Boolean verifyFirstStringArg( char *strArg )
{
    // check for all possible string arg 1 possiblities
    if( compareString( strArg, "access") == STR_EQ
        || compareString( strArg, "allocate") == STR_EQ
        || compareString( strArg, "end") == STR_EQ
        || compareString( strArg, "ethernet") == STR_EQ
        || compareString( strArg, "hard drive") == STR_EQ
        || compareString( strArg, "keyboard") == STR_EQ
        || compareString( strArg, "monitor") == STR_EQ
        || compareString( strArg, "printer") == STR_EQ
        || compareString( strArg, "process") == STR_EQ
        || compareString( strArg, "serial") == STR_EQ
        || compareString( strArg, "sound signal") == STR_EQ
        || compareString( strArg, "start") == STR_EQ
        || compareString( strArg, "usb") == STR_EQ
        || compareString( strArg, "video signal") == STR_EQ )
    {
        return True;
    }

    // if not then false
    return False;
}


/*
Function Name: varifyValidCommand
Algorithm: check string argument for one of the allowed commands
Precondition: input string is provided
Postcondition: in correct operationl
            reports if given string is a command,
            false if not
Exceptions: none
Notes: none
*/
Boolean verifyValidCommand( char *testCmd )
{
    // check for 5 string command args
    if( compareString( testCmd, "sys" ) == STR_EQ
        || compareString( testCmd, "app" ) == STR_EQ
        || compareString( testCmd, "cpu" ) == STR_EQ
        || compareString( testCmd, "mem" ) == STR_EQ
        || compareString( testCmd, "dev" ) == STR_EQ )
    {
        return True;
    }

    // else false
    return False;
}