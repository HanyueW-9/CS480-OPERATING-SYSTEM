//Pre-comp directives
#ifndef SUPPORTFUNCTIONS_H
#define SUPPORTFUNCTIONS_H

#include <stdio.h>
#include <pthread.h> // for spinTimer
#include "simtimer.h" // for spinTimer
#include "datatypes.h" // for file log support

// declerations
void showProgramFormat();
void* spinTimer(void* cycleTime);
int calculateRemainingTime(PCBType *PCB, int ioCycleTime, int cpuCycleTime);
logFileTextType *addTextNode( logFileTextType* localPtr, logFileTextType* newNode );
//void *testThreadFunc( void* t ); // See comment in-file

#endif //SUPPORTFUNCTIONS_H 
