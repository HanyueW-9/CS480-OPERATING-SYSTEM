// header files
#include "PCB.h"

// A function that takes in an entire list of metadata
// and formats it into a well-formed linked list of PCBs
// each PCB contains data for one full program (App Start to App end)
PCBType *createPCBs( OpCodeType *metaDataMstrPtr, int ioCycleTime, int cpuCycleTime)
{
    // initializes variables
        // current process number
    int currentProcess = -1;

    // a variable to keep track of remaining time in each pcb
    int timeCounter = 0;

        // local head pointer
    OpCodeType *localMDPointer = metaDataMstrPtr;

        // PCB to fill out
    PCBType *PCB = NULL;

        // new PCB node
    PCBType *newNodePtr = ( PCBType * )malloc( sizeof( PCBType ) );

        // flag for storing metadata
    Boolean isApp = False;

    // fill out pcb defaults
    newNodePtr->PCBID = 0;
    newNodePtr->state = NEW;
    newNodePtr->remainingTime = 0;
    newNodePtr->processList = NULL;
    newNodePtr->nextNode = NULL;


    // Loops through all metadata
    while(localMDPointer != NULL)
    {
        // Checks if new process is starting or ending
        if(compareString( localMDPointer->command, "app" ) == STR_EQ )
        {
            // if starting
            if(compareString( localMDPointer->strArg1, "start" ) == STR_EQ )
            {
                // Increments current ID values
                currentProcess += 1;
                newNodePtr->PCBID = currentProcess;

                // sets flag (because we're now in an app)
                isApp = True;
            }

            // if ending
            else if(compareString( localMDPointer->strArg1, "end" ) == STR_EQ )
            {
                // adds the metadata node
                localMDPointer->pid = currentProcess;
                newNodePtr->processList = addNode(newNodePtr->processList, localMDPointer);

                // sets the finished time for the PCB
                newNodePtr->remainingTime = timeCounter;

                // adds the temp PCB to the list fo PCBs
                PCB = addPCBNode( PCB, newNodePtr );

                // No longer in an App
                isApp = False;

                // Reset defaults for next app
                newNodePtr->state = NEW;
                newNodePtr->remainingTime = 0;
                newNodePtr->processList = NULL;
                newNodePtr->nextNode = NULL;
                timeCounter = 0;
            }
        }

        // if we're in the middle of an app (that has started)
        if(isApp == True)
        {
            // finds the time for the current process (if it has run time)
            if(compareString( localMDPointer->command, "dev" ) == STR_EQ)
            {
                timeCounter += (ioCycleTime * localMDPointer->intArg2);
            }

            else if(compareString( localMDPointer->command, "cpu" ) == STR_EQ)
            {
                timeCounter += (cpuCycleTime * localMDPointer->intArg2);
            }           

            // sets the current process as a new node in the current pcb
            localMDPointer->pid = currentProcess;
            newNodePtr->processList = addNode(newNodePtr->processList, localMDPointer);
        }

        // always loops by going to next metadata node
        localMDPointer = localMDPointer->nextNode;

    } // end metadata loop

    // free memory
    free(newNodePtr);

    // returns pointer to PCB head
    return PCB;
}


// An adapted version of the addNode function used for the metadata linked list
PCBType *addPCBNode( PCBType* localPtr, PCBType* newNode )
{
    // check for local pointer assigned to null
    if( localPtr == NULL )
    {
        // access memory for new link/node
        localPtr = (PCBType* )malloc( sizeof( PCBType ));

        // assign all values to newly created node
        localPtr->PCBID = newNode->PCBID;
        localPtr->state = newNode->state;
        localPtr->remainingTime = newNode->remainingTime;
        localPtr->processList = newNode->processList;
    
        // assign next pointer to null
        localPtr->nextNode = NULL;
        
        // return current local pointer
        return localPtr;
    }

    // assume end of list not found yet
    // assign recuresive function to current's next linke
    localPtr->nextNode = addPCBNode( localPtr->nextNode, newNode );

    // return current local pointer
    return localPtr;
}

// takes in a state
// looks it up in the ENUM and returns it as a string
char *stateToString(int currentState)
{
    // initialize return
    char *returnValue = "NEW";

    switch( currentState )
    {
        case READY:
            returnValue = "READY";
            break;

         case RUNNING:
            returnValue = "RUNNING";
            break;

         case BLOCKED:
            returnValue = "BLOCKED";
            break;

         case EXITING:
            returnValue = "EXITING";
            break;
    }

    return returnValue;
}

// a function that takes in the current Linked List of PCBs and a schedule type
// then re-arranges them in the appropriate order
// returns a pointer to the first item
// NOTE: only works with FCFS-N as per Sim02 instructions (error checking is in ConfigAccess)
PCBType *setScheduleType( PCBType *PCB, int cpuSchedCode )
{
    // initialize variables and various instances PCB copies
    PCBType *localPCBLooper = ( PCBType * )malloc( sizeof( PCBType ) );
    PCBType *newPCB = ( PCBType * )malloc( sizeof( PCBType ) );
    int lowestVal;

    // FCFS is the same as default sorting (Premptive and Round Robit are identical without premption)
    if( cpuSchedCode == CPU_SCHED_FCFS_N_CODE)
    {
        free( localPCBLooper );
        free( newPCB );
        return PCB;
    }


    // currently causes Segmentation Fault
    if( cpuSchedCode == CPU_SCHED_SJF_N_CODE)
    {
        // initializes variables
        lowestVal = PCB->remainingTime;

        // loops through all items
        while( PCB != NULL )
        {
            // compares each to all other items
            while(PCB != NULL )
            {
                // if the new item is smaller, it ads it to the front of the new list
                if( PCB->remainingTime < lowestVal )
                {
                    lowestVal = PCB->remainingTime;
                    newPCB->PCBID = PCB->PCBID;
                    newPCB->state = PCB->state;
                    newPCB->remainingTime = PCB->remainingTime;
                    newPCB->processList = PCB->processList;
                    newPCB->nextNode = NULL;

                    localPCBLooper = addPCBNode(localPCBLooper, newPCB);
                    
                }
                PCB = PCB->nextNode;
            }
            PCB = PCB->nextNode;
        }
        return localPCBLooper;
    }

    // without premption SRTF-P is identical to SJF-N
    // as such, it also causes a segmentation fault
    if( cpuSchedCode == CPU_SCHED_SRTF_P_CODE)
    {
        // initializes variables
        lowestVal = PCB->remainingTime;

        // loops through all items
        while( PCB != NULL )
        {
            // compares each to all other items
            while(PCB != NULL )
            {
                // if the new item is smaller, it ads it to the front of the new list
                if( PCB->remainingTime < lowestVal )
                {
                    lowestVal = PCB->remainingTime;
                    newPCB->PCBID = PCB->PCBID;
                    newPCB->state = PCB->state;
                    newPCB->remainingTime = PCB->remainingTime;
                    newPCB->processList = PCB->processList;
                    newPCB->nextNode = NULL;

                    localPCBLooper = addPCBNode(localPCBLooper, newPCB);
                    
                }
                PCB = PCB->nextNode;
            }
            PCB = PCB->nextNode;
        }
        return localPCBLooper;
    }

    else
    {
        free( localPCBLooper );
        free( newPCB );
        return PCB;
    }
        
}
