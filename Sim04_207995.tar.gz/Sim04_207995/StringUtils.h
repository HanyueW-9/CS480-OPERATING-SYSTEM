//Pre-comp directives
#ifndef STRING_UTILS_H
#define STRING_UTILS_H

// header files
#include <stdio.h> // file operations
#include <stdlib.h> // dynamic memory ops
#include "datatypes.h"

// create global constants - across files
typedef enum {
    NO_ERR,
    INCOMPLETE_FILE_ERR,
    INPUT_BUFFER_OVERRUN_ERR} StringManipCode;

// create global constants
extern const int STD_STR_LEN;
extern const int MAX_STR_LEN;
extern const int SUBSTRING_NOT_FOUND;
extern const int STR_EQ;
extern const char SPACE;
extern const char NULL_CHAR;
extern const char COLON;
extern const char SEMICOLON;
extern const char PERIOD;
extern const char COMMA;
extern const char LEFT_PAREN;
extern const char RIGHT_PAREN;
extern const Boolean IGNORE_LEADING_WS;
extern const Boolean ACCEPT_LEADING_WS;


// function prototypes
int getStringLength(char* testStr);
void copyString(char* destStr, char* sourceStr);
void concatString(char* destStr, char* sourceStr);
int compareString(char* destStr, char* sourceStr);
void getSubString(char* destStr, char* sourceStr, 
                                int startIndex, int endIndex);
int findSubString(char* testStr, char* searchSubStr);
void setStrLowerCase(char* destStr, char* sourceStr);
char setCharLowerCase(char testChar);
int getLineTo( FILE *filePtr, int bufferSize, char stopChar, 
      char *buffer, Boolean omitLeadingWhiteSpace, Boolean stopAtNonPrintable );
Boolean isEndOfFile(FILE* filePtr);

#endif //STRING_UTILS_H
