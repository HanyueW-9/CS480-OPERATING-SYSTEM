// Header Files
#include "OS_SimDriver.h"

int main( int argc, char **argv)
{


    // Initialize variables
    Boolean programRunFlag = False;
    Boolean configDisplayFlag = False;
    Boolean configUploadFlag = False;
    Boolean mdDsiplayFlag = False;
    Boolean runSimFlag = False;
    Boolean infoFlag = False;
    int argIndex = 1;
    int lastFourLetters = 4;
    int fileStrLen, fileStrSubLoc;
    char fileName [ STD_STR_LEN ];
    char errorMessage [ MAX_STR_LEN ];
    ConfigDataType *configDataPtr = NULL;
    OpCodeType *metaDataPtr = NULL;


    // display title
    printf("\nSimulator Program\n");
    printf("============================\n\n");

    // check for one arg
    if( argc < 2 )
    {
        // show error message and end program
        showProgramFormat();

        programRunFlag = False;
        infoFlag = True;
    }

    // initialize file name
    fileName [ 0 ] = NULL_CHAR;

    // Loop across args
    while( programRunFlag == False && argIndex < argc)
    {
        // verify file name
        fileStrLen = getStringLength( argv[ argIndex ] );
        fileStrSubLoc = findSubString( argv[ argIndex ], ".cnf" );

        // check for -dc (config display)
        if( compareString ( argv[ argIndex ], "-dc" ) == STR_EQ)
        {
            configUploadFlag = True;
            configDisplayFlag = True;
        }

        // check for -dm (display metadata)
        else if( compareString( argv[ argIndex ], "-dm" ) == STR_EQ )
        {
            configUploadFlag = True;
            mdDsiplayFlag = True;
        }

        // check for -rs (run simulator)
        else if( compareString( argv[ argIndex ], "-rs" ) == STR_EQ)
        {
            configUploadFlag = True;
            runSimFlag = True;
        }

        // otherwise check for file name ending in .cnf
        else if( fileStrSubLoc != SUBSTRING_NOT_FOUND
                    && fileStrSubLoc == fileStrLen - lastFourLetters )
        {
            copyString( fileName, argv[ argIndex ] );

            programRunFlag = True;
        }
        
        // update loop
        argIndex++;
    }

    // check for cmd failure
    if( programRunFlag == False && infoFlag == False )
    {
        printf( "Incorrect argument line format, program aborted\n\n" );

        // Help the user
        showProgramFormat();
    }


    // check for program run and config upload
    if( programRunFlag == True && configUploadFlag == True )
    {
        // upload config file and check for success
        if( getStringLength( fileName ) > 0
            && getConfigData( fileName, &configDataPtr, errorMessage ) == True )
        {
            // check if want it displayed
            if( configDisplayFlag == True )
            {
                displayConfigData( configDataPtr );
            }
        }

        // otherwise assume config upload failure
        else
        {
            // Displays error message
            printf( "\nConfig Upload Error: %s, program aborted\n\n",
                                                                errorMessage );

            programRunFlag = False;
        }
    }

    // check program run flag
    if( programRunFlag == True 
                        && ( mdDsiplayFlag == True || runSimFlag == True ) )
    {
        // upload meta data file and check success
        if( getMetaData( configDataPtr->metaDataFileName,
                                                    &metaDataPtr, errorMessage ) == True )
        {
            if( mdDsiplayFlag == True )
            {
                displayMetaData( metaDataPtr );
            }

            if( runSimFlag == True )
            {
                runSim( configDataPtr, metaDataPtr );
            }
        }

        // otherwise assume meta data upload failure
        else
        {
            printf( "\nMetadata Upload Error: %s, program aborted\n",
                                                            errorMessage );
        }
    }

    // clean up memory
    configDataPtr = clearConfigData( configDataPtr );
    metaDataPtr = clearMetaDataList( metaDataPtr );

    // program end
    printf( "\nSimulator Program Ended.\n\n" );


    // return success
    return 0;
}