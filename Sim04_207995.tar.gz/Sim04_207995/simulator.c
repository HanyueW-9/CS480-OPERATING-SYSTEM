// header files
#include "simulator.h"

/*
Function Name: runSim
Algortihm: master driver for simulator operations;
            conducts OS simulation with varying scheduling strategies
            and varying numbers of processes
Precondition: given head pointer to config data and meta data
Postcondition: simulation is provided, file output is provided as configured
Exceptions: none
Notes: none
*/
void runSim( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr )
{

    // Initializes output flags
    Boolean logToFile =False;
    Boolean logToMonitor = False;
    int logCode = configPtr->logToCode;

    if( logCode == LOGTO_FILE_CODE )
    {
        logToFile = True;
    }

    else if( logCode == LOGTO_MONITOR_CODE )
    {
        logToMonitor = True;
    }

    // otherwise logto both
    else
    {
        logToFile = True;
        logToMonitor = True;
    }

    logToFile = True;
    logToMonitor = True;

    // Initializes file I/O
    FILE *fptr;
    fptr = fopen(configPtr->logToFileName, "w");
    logFileTextType *logToFileString = NULL;
    char testText[ 200 ];


    // Display simulator title
    sprintf(testText, "\nSimulator Run\n");
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    sprintf(testText, "------------------\n\n");
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    // Initializes timer variables and starts timer
    char timeString[11];
    accessTimer(ZERO_TIMER, timeString);
    sprintf(testText, "%s, OS: Simulation start\n", timeString);
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    // initializes other variables 
        // PCB for process management
    PCBType *PCB = NULL;
    int ioCycleTime = configPtr->ioCycleRate;
    int cpuCycleTime = configPtr->procCycleRate;

    // creates all processes in NEW state
    PCB = createPCBs(metaDataMstrPtr, ioCycleTime, cpuCycleTime);

    // arranges PCBs in appropriate order
    PCB = setScheduleType(PCB, configPtr->cpuSchedCode);

    // sets all initial processes to ready
        // initializes local alias for setting state
    PCBType *localPCBHead = PCB;

    while( localPCBHead != NULL )
    {
        logToFileString = setState(localPCBHead, READY, timeString, logToFileString, logToFile, logToMonitor);

        // loops to next value in linked list
        localPCBHead = localPCBHead->nextNode;
    }

    sprintf(testText,"\n");
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    // Loops through processes and runs them in their proper order
        // resets local head for this
    localPCBHead = PCB;

    //pthread_t tid;
    //pcbThreadArgs *PCBArgs = (pcbThreadArgs*)malloc(sizeof(pcbThreadArgs));

    while( localPCBHead != NULL )
    {
        /*
        // sets up the args for the thread
        PCBArgs->time = timeString;
        PCBArgs->PCB = localPCBHead;
        PCBArgs->logToFileString = logToFileString;
        PCBArgs->ioCycleTime = ioCycleTime;
        PCBArgs->cpuCycleTime = cpuCycleTime;
        */

        // does initial display for selection
        accessTimer(LAP_TIMER, timeString);

        // outputs selection
        sprintf(testText, "%s, OS: Process %d  selected,   %d  ms remaining\n", timeString, localPCBHead->PCBID, localPCBHead->remainingTime);
        logToFileString = outputText(logToFileString, testText, True, True);
        
        logToFileString = setState(localPCBHead, RUNNING, timeString, logToFileString, logToFile, logToMonitor);

        sprintf(testText, "\n"); // new line for good spacing
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

        // creates a thread for the process
        //pthread_create(&tid, NULL, testThreadFunc, (void*) PCBArgs );


        // loops through all operations in this app
        while(localPCBHead->processList != NULL)
        {
            // times and displays current op/process
            logToFileString = displayProcess(localPCBHead->processList, timeString, ioCycleTime, cpuCycleTime, logToFileString, logToFile, logToMonitor);

            // loops to next value in linked list
            localPCBHead->processList = localPCBHead->processList->nextNode;
        }

        // displays the current process/app exiting
        logToFileString = setState(localPCBHead, EXITING, timeString, logToFileString, logToFile, logToMonitor);

        sprintf(testText, "\n"); // new line for good spacing
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

        localPCBHead = localPCBHead->nextNode;
    }

    //pthread_join(tid, NULL);


    // shuts down simulation
    accessTimer(STOP_TIMER, timeString);
    sprintf(testText, "%s, OS: Simulation end\n", timeString);
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    // Finally, prints the output to the log file
    if(logToFile == True)
    {
        logFileTextType *localFileHead = logToFileString;
        while(localFileHead != NULL)
        {
            fprintf(fptr, localFileHead->currentText);
            localFileHead = localFileHead->nextNode;
        }
    }

    // free all memory once done
    fclose( fptr );
    free( localPCBHead );
    free( PCB );
    free( logToFileString );
}


// a function that takes in a current PCB and a state (and timer string)
// and sets the PCB to that state and prints the result
logFileTextType *setState( PCBType *PCB, int newState, char *timeString, logFileTextType *logToFileString, Boolean logToFile, Boolean logToMonitor )
{
    // sets variables
    int oldState = PCB->state;
    PCB->state = newState;
    char testText[200];

    // accesses timer and prints result
    accessTimer(LAP_TIMER, timeString);
    sprintf(testText, "%s, OS: Process %d  set to   %s  state from  %s  state  \n", timeString, PCB->PCBID, stateToString(newState), stateToString(oldState));
    logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

    return logToFileString;
}

// Takes in a process/operation, the running timeString, and cycle time information from the config file
// Does not return, but instead calls the appropriate support functions for different operations
logFileTextType *displayProcess(OpCodeType *currentProcess, char *timeString, int ioCycleTime, int cpuCycleTime, logFileTextType *logToFileString, Boolean logToFile, Boolean logToMonitor )
{
    // aliases linked list input
    OpCodeType *localMDHead = currentProcess;

    // app and sys command auto-pass 

    // initialize variables used in all sub-sections
    int ID = currentProcess->pid;
    pthread_t tid;
    char testText[200];

    // handles dev I/O commands
    if(compareString( localMDHead->command, "dev" ) == STR_EQ)
    {
        // initializes variables for output and comparison
        long currentCycleTime = currentProcess->intArg2 * ioCycleTime;
        char *devType = currentProcess->inOutArg;
        char *devDevice = currentProcess->strArg1;

        // prints starting value
        accessTimer(LAP_TIMER, timeString);
        sprintf(testText, "%s, OS: Process %d, %s %s operation start\n", timeString, ID, devDevice, devType);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

        // waits for a timer to spin
        pthread_create( &tid, NULL, spinTimer, (void*) currentCycleTime );
        pthread_join(tid, NULL);

        // prints ending value
        accessTimer(LAP_TIMER, timeString);
        sprintf(testText, "%s, OS: Process %d, %s %s operation end\n", timeString, ID, devDevice, devType);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);
    }

    // handles cpu commands
    else if(compareString( localMDHead->command, "cpu" ) == STR_EQ)
    {
        long numCycles = currentProcess->intArg2; // * cpuCycleTime; 
        char *cpuAction = currentProcess->strArg1;
        long cycleTime = cpuCycleTime;
        Boolean inturruptFlag = False;
        Boolean setCyclesFlag = True;
        int remainingCycles = numCycles;

        // prints starting value
        accessTimer(LAP_TIMER, timeString);
        sprintf(testText, "%s, OS: Process %d, cpu %s  operation start\n", timeString, ID, cpuAction);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

        // waits for a timer to spin
        while(numCycles > 0)
        {
            // if inturrupt happened
            if(inturruptFlag == True)
            {
                // if its the first time here
                if(setCyclesFlag == True)
                {
                    // set the remaining cycles
                    remainingCycles = numCycles;

                    // sets the remaining cycles in the process
                    currentProcess->intArg2 = remainingCycles;
                    
                    // sets the flag so it doesn't return here
                    setCyclesFlag = False;
                }

                // else just spin out the loop
            }

            // not inturrupted, run next cycle
            else
            {
                pthread_create( &tid, NULL, spinTimer, (void*) cycleTime );
                pthread_join(tid, NULL);
            }

            // always decriments loop
            numCycles = numCycles - 1;

        }

        // sets remaining cycles after loop ends
        numCycles = remainingCycles;


        // prints ending value
        accessTimer(LAP_TIMER, timeString);
        sprintf(testText, "%s, OS: Process %d, cpu %s  operation end\n", timeString, ID, cpuAction);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);
    }

    // handles mem commands
    else if(compareString( localMDHead->command, "mem" ) == STR_EQ)
    {
        accessTimer(LAP_TIMER, timeString);
        sprintf(testText, "%s, OS: Process %d, attempting mem allocate request\n", timeString, ID);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);

        sprintf(testText, "%s, OS: Process %d, failed mem allocate request\n", timeString, ID);
        logToFileString = outputText(logToFileString, testText, logToFile, logToMonitor);
    }

    // frees temporary memory
    free( localMDHead );

    return logToFileString;
}


// A function that takes in a running log string, flags that tell it where to log, and an incoming new string
// If logging to monitor, it simply prints the new string
// If logging to file, it adds a node to a linked list that will be printed at program completion
logFileTextType *outputText(logFileTextType *logToFileString, char srcStr[ 200 ], Boolean fileFlag, Boolean monitorFlag)
{ 
    // if logTo monitor
    if(monitorFlag == True)
    {
        printf(srcStr); // prints to monitor
    }

    // if logTo file
    if(fileFlag == True)
    {
        logFileTextType *newTextNode = ( logFileTextType * )malloc( sizeof( logFileTextType ) );
        sprintf(newTextNode->currentText, srcStr); // saves the text to a string
        newTextNode->nextNode = NULL;
        logToFileString = addTextNode( logToFileString, newTextNode ); // adds a node to a linked list with the text as its value

        free(newTextNode);
    }

    return logToFileString;
}


