//Pre-comp directives
#ifndef SIMULATOR_H
#define SIMULATOR_H

// dependencies
#include <stdio.h> // for output
#include <pthread.h> // for timer threads
#include "ConfigAccess.h"
#include "MetaDataAccess.h"
#include "simulator.h"
#include "PCB.h"
#include "simtimer.h"
#include "datatypes.h"
#include "SupportFunctions.h"
#include "StringUtils.h" // for max string length

// functions
void runSim( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr );
logFileTextType *setState( PCBType *PCB, int newState, char *timeString, logFileTextType *logToFileString, Boolean logToFile, Boolean logToMonitor );
logFileTextType *displayProcess(OpCodeType *currentProcess, char *timeString, int ioCycleTime, int cpuCycleTime, logFileTextType *logToFileString, Boolean logToFile, Boolean logToMonitor );
logFileTextType *outputText(logFileTextType *logToFileString, char srcStr[200], Boolean fileFlag, Boolean monitorFlag);

#endif //SIMULATOR_H 