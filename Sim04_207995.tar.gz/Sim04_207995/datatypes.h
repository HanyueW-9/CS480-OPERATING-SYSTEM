//Pre-comp directives
#ifndef DATATYPES_H
#define DATATYPES_H

typedef enum { False, True } Boolean;

// config data structure
typedef struct ConfigDataType
{
    double version;
    char metaDataFileName[100];
    int cpuSchedCode;
    int quantumCycles;
    long int memAvaliable;
    int procCycleRate;
    int ioCycleRate;
    int logToCode;
    char logToFileName[100];
} ConfigDataType;


// op code data structure
typedef struct OpCodeType
{
    int pid;                // pid added when PCB is created
    char command[ 5 ];      // three letter command quantity
    char inOutArg[ 5 ];     // for device in/out
    char strArg1[ 15 ];     // arg 1 descriptor, up to 12 chars
    int intArg2;               // cycles or memory, assumes 4 byte int
    int intArg3;            // memory, assumes 4 byte int
                                // also non/premption indicator
    double opEndTime;       // size of time string returned from accessTimer
    struct OpCodeType *nextNode;    // pointer to next node as needed
} OpCodeType;

// possible process states
typedef enum
{
    NEW,
    READY,
    RUNNING,
    BLOCKED,
    EXITING
} ProcessState;

// each node of the PCB has a number ID and a reference to the operations to peform
typedef struct PCBType
{
    int PCBID;                      // added upon pcb creation
    int state;                      // current process state
    int remainingTime;              // total amount of time to run the process
    struct OpCodeType *processList; // list of the operations/processes this PCB handles
    struct PCBType *nextNode;       // pointer to next node as needed
} PCBType;

// A datatype for the file logging system
typedef struct logFileTextType
{
    char currentText[ 200 ];
    struct logFileTextType *nextNode;
} logFileTextType;

// a datatype to contain all of the information the main PCB threads will need
typedef struct pcbThreadArgs
{
    char *time;
    PCBType *PCB;
    logFileTextType *logToFileString;
    int ioCycleTime;
    int cpuCycleTime;

} pcbThreadArgs;

#endif //DATATYPES_H 
