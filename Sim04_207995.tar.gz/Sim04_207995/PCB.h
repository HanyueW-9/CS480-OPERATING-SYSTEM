//Pre-comp directives
#ifndef PCB_H
#define PCB_H

// dependencies
#include <stdio.h> // for output
#include "StringUtils.h"
#include "MetaDataAccess.h"
#include "datatypes.h"
#include "ConfigAccess.h" // for sched types

// functions
PCBType *createPCBs( OpCodeType *metaDataMstrPtr, int ioCycleTime, int cpuCycleTime);
PCBType *addPCBNode( PCBType* localPtr, PCBType* newNode );
PCBType *setScheduleType( PCBType *PCB, int cpuSchedCode );
char *stateToString(int currentState);


#endif //PCB_H 