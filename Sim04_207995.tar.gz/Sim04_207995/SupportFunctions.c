#include "SupportFunctions.h"

/*
name: showProgramFormat
process: displays cmd argument requirements for this program
*/
void showProgramFormat()
{
    printf( "Program Format:\n" );
    printf( "   sim_01 [-dc] [-dm] [-rs] <config file name>\n" );
    printf( "   -dc [optional] displays configuration data\n" );
    printf( "   -dm [optional] displays meta data\n" );
    printf( "   -rs [optional] runs simulator\n" );
    printf( "   config file name is required\n" );
}


// takes in a number of milliseconds
// waits that period of time before exiting
void* spinTimer(void* cycleTime)
{
    runTimer((long) cycleTime);
    pthread_exit(NULL);
}

// A program that loops through ops/commands and calculates remaining time for the PCB
int calculateRemainingTime(PCBType *aliasPCB, int ioCycleTime, int cpuCycleTime)
{
    // initializes variables
    int remainingTime = 0;

    // loops through all ops
    while(aliasPCB->processList != NULL)
    {
        // checks if it's one of the two kinds that spin the timer
        if(compareString( aliasPCB->processList->command, "dev" ) == STR_EQ)
        {
            remainingTime += (ioCycleTime * aliasPCB->processList->intArg2);
        }

        else if(compareString( aliasPCB->processList->command, "cpu" ) == STR_EQ)
        {
            remainingTime += (cpuCycleTime * aliasPCB->processList->intArg2);
        }

        // increments loop
        aliasPCB->processList = aliasPCB->processList->nextNode;
    }

    return remainingTime;
}

// A function for adding nodes to a linked list
// the list stores nodes that only contain a text value
// it is used for storing output to print to file at the end of execution
logFileTextType *addTextNode( logFileTextType* localPtr, logFileTextType* newNode )
{
    if( localPtr == NULL )
    {
        localPtr = ( logFileTextType* )malloc( sizeof( logFileTextType ));

        // assign all values to newly created node
        sprintf(localPtr->currentText, newNode->currentText);
        localPtr->nextNode = NULL;

        // return current local pointer
        return localPtr;
    }

    // assume end of list not found yet
    // assign recuresive function to current's next linke
    localPtr->nextNode = addTextNode( localPtr->nextNode, newNode );

    // return current local pointer
    return localPtr;
}


/*
This function was my primary attempt to get concurrency running.  It was called from simulator.c
The goal was for a thread to be created for each process (PCB), and each one would call this block.
After entering this block, each thread would start looping through the OPCodes of their associated
process.  The "Running" state would be locked via mutex lock, causing the rest of them to wait.

This implementation failed miserably and I reverted some of the simulator.c code so that it would still
function without concurrency.
*/

/*
// Defunct thread function start
void *testThreadFunc( void* PCBArgs )
{

    //pthread_mutex_lock( &mutex );
    char* time = (( pcbThreadArgs*)PCBArgs)->time;
    PCBType* PCB = ((pcbThreadArgs*)PCBArgs )->PCB;
    logFileTextType* logToFileString = (( pcbThreadArgs*)PCBArgs)->logToFileString;
    int ioCycleTime = (( pcbThreadArgs*)PCBArgs)->ioCycleTime;
    int cpuCycleTime = (( pcbThreadArgs*)PCBArgs)->cpuCycleTime;
    char testText[ 200 ];


    //logToFileString = setState(PCB, RUNNING, time, logToFileString, True, True);

    sprintf(testText, "\n"); // new line for good spacing

    logToFileString = outputText(logToFileString, testText, True, True);
    //pcbThreadArgs Args = (pcbThreadArgs*) PCBArgs;


    // loops through all operations in this app
    while(PCB->processList != NULL)
    {
        // times and displays current op/process
        logToFileString = displayProcess(PCB->processList, time, ioCycleTime, cpuCycleTime, logToFileString, True, True);

        // loops to next value in linked list
        PCB->processList = PCB->processList->nextNode;
    }

    //PCB = PCB->nextNode;

    //pthread_mutex_unlock( &mutex );

    return NULL;
}

*/